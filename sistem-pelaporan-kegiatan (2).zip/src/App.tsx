import React, { useState, useEffect } from "react";
import { 
  FileText, Plus, Search, Calendar, MapPin, User, Award, 
  ChevronDown, ChevronUp, Printer, Edit2, Check, X, Sparkles, 
  Trash2, Filter, AlertCircle, RefreshCw, BarChart2, BookOpen,
  LogOut, LogIn, Lock
} from "lucide-react";
import { Kegiatan, UserSession } from "./types";
import { filterKegiatan, formatLabelDate, getLockedIndonesianDate } from "./utils";
import ReportForm from "./components/ReportForm";
import ReportPrintView from "./components/ReportPrintView";
import GlobalRekapPrintView from "./components/GlobalRekapPrintView";

const DEMO_ACCOUNTS: UserSession[] = [
  {
    name: "Rayhand Tirtadistira",
    email: "yourock@gmail.com",
    nip: "199208152019011004",
    jabatan: "Analis Sistem Informasi & Teknologi",
    avatarUrl: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=120&h=120"
  },
  {
    name: "Humayra Ramadhani",
    email: "humayraramadhani@gmail.com",
    nip: "199512122020032015",
    jabatan: "Super Administrator Sistem SIAAP LAPOR",
    avatarUrl: "https://api.dicebear.com/7.x/initials/svg?seed=Humayra"
  },
  {
    name: "Bidang Infraswil",
    email: "infraswil@pohuwatokab.go.id",
    nip: "199308182022031013",
    jabatan: "Analisis Infrastruktur",
    avatarUrl: "https://api.dicebear.com/7.x/initials/svg?seed=Infraswil"
  },
  {
    name: "Bidang P2EPD",
    email: "p2epd@pohuwatokab.go.id",
    nip: "198104042010012003",
    jabatan: "Pengelola Monev",
    avatarUrl: "https://api.dicebear.com/7.x/initials/svg?seed=P2EPD"
  },
  {
    name: "Bidang P3SDA",
    email: "p3sda@pohuwatokab.go.id",
    nip: "198307152007012004",
    jabatan: "Analisis Data Ilmiah Ahli Muda",
    avatarUrl: "https://api.dicebear.com/7.x/initials/svg?seed=P3SDA"
  },
  {
    name: "Bidang Risnovda",
    email: "risnovda@pohuwatokab.go.id",
    nip: "197910052007011015",
    jabatan: "Analisis Pemanfaatn Iptek Ahli Muda",
    avatarUrl: "https://api.dicebear.com/7.x/initials/svg?seed=Risnovda"
  },
  {
    name: "Sekretariat Bapppeda",
    email: "setbapppeda@pohuwatokab.go.id",
    nip: "197209082000122004",
    jabatan: "Kasubbag Umum Dan Kepegawaian",
    avatarUrl: "https://api.dicebear.com/7.x/initials/svg?seed=Sekretariat"
  }
];

// Pemetaan PIN Akses untuk masing-masing email resmi
const EMAIL_PIN_MAP: Record<string, string> = {
  "humayraramadhani@gmail.com": "811255",
  "yourock@gmail.com": "250526",
  "infraswil@pohuwatokab.go.id": "031013",
  "p2epd@pohuwatokab.go.id": "012003",
  "p3sda@pohuwatokab.go.id": "012004",
  "risnovda@pohuwatokab.go.id": "011015",
  "setbapppeda@pohuwatokab.go.id": "122004"
};

// Daftar email yang diizinkan untuk menghapus data (Akses Administrator)
const ALLOWED_DELETE_EMAILS = [
  "humayraramadhani@gmail.com",
  "yourock@gmail.com"
];

// Daftar email resmi yang diizinkan masuk ke dalam Sistem (Sistem Whitelist Pegawai)
const REGISTERED_EMAILS_WHITELIST = [
  "humayraramadhani@gmail.com",
  "yourock@gmail.com",
  "infraswil@pohuwatokab.go.id",
  "p2epd@pohuwatokab.go.id",
  "p3sda@pohuwatokab.go.id",
  "risnovda@pohuwatokab.go.id",
  "setbapppeda@pohuwatokab.go.id"
];

export default function App() {
  // Activity state from database
  const [activities, setActivities] = useState<Kegiatan[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);
  
  // Real-time synchronization state indicator
  const [syncStatus, setSyncStatus] = useState<"connected" | "syncing" | "offline">("connected");

  // Search & Filters State
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFilter, setDateFilter] = useState<"all" | "today" | "yesterday" | "this_week">("all");
  const [isFilterCollapsed, setIsFilterCollapsed] = useState(false);

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // Views & Modal States
  const [showAddForm, setShowAddForm] = useState(false);
  const [currentPrintActivity, setCurrentPrintActivity] = useState<Kegiatan | null>(null);
  const [showRekapPrint, setShowRekapPrint] = useState(false);

  // Inline Editing State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editNip, setEditNip] = useState("");
  const [editJabatan, setEditJabatan] = useState("");
  const [editResume, setEditResume] = useState("");
  const [isUpdatingAI, setIsUpdatingAI] = useState(false);
  const [inlineError, setInlineError] = useState<string | null>(null);

  // Collapsed Card detail list
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Authentication & Google Sign-In states
  const [currentUser, setCurrentUser] = useState<UserSession | null>(() => {
    const saved = localStorage.getItem("siaap_lapor_auth_session");
    return saved ? JSON.parse(saved) : null;
  });
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginLoading, setLoginLoading] = useState(false);
  const [isCustomLogin, setIsCustomLogin] = useState(false);

  // PIN & Identity Verification States
  const [verifyingUser, setVerifyingUser] = useState<UserSession | null>(null);
  const [enteredPin, setEnteredPin] = useState("");
  const [pinError, setPinError] = useState("");
  const [whitelistError, setWhitelistError] = useState("");

  // Custom Google User custom creation states
  const [customName, setCustomName] = useState("");
  const [customEmail, setCustomEmail] = useState("");
  const [customNip, setCustomNip] = useState("");
  const [customJabatan, setCustomJabatan] = useState("");

  const handleSelectAccount = (account: UserSession) => {
    setPinError("");
    setWhitelistError("");
    setEnteredPin("");
    setVerifyingUser(account);
  };

  const handleCustomLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setWhitelistError("");
    setPinError("");
    
    if (!customName.trim() || !customEmail.trim() || !customNip.trim() || !customJabatan.trim()) {
      setWhitelistError("Semua kolom bertanda bintang (*) wajib diisi.");
      return;
    }

    const emailLower = customEmail.trim().toLowerCase();
    const isWhitelisted = REGISTERED_EMAILS_WHITELIST.includes(emailLower);

    if (!isWhitelisted) {
      setWhitelistError(`Akses Ditolak: Email (${customEmail}) tidak terdaftar dalam database resmi Kepegawaian Bapppeda Kabupaten Pohuwato. Silakan gunakan email dinas yang sah atau hubungi unit IT Bappeda.`);
      return;
    }

    // Email is whitelisted, proceed to 2-step PIN verification code
    const user: UserSession = {
      name: customName.trim(),
      email: emailLower,
      nip: customNip.trim(),
      jabatan: customJabatan.trim(),
      avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(customName.trim())}`
    };

    setEnteredPin("");
    setVerifyingUser(user);
  };

  const handleVerifyPinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError("");
    
    if (!verifyingUser) return;

    const emailLower = (verifyingUser.email || "").trim().toLowerCase();
    const correctPin = EMAIL_PIN_MAP[emailLower] || "123456";

    // Secure 6-digit PIN verification constraint
    if (enteredPin.trim() !== correctPin) {
      setPinError("Sandi atau PIN Keamanan tidak cocok. Akses Sistem Pelaporan Ditolak.");
      return;
    }

    setLoginLoading(true);
    setTimeout(() => {
      setCurrentUser(verifyingUser);
      localStorage.setItem("siaap_lapor_auth_session", JSON.stringify(verifyingUser));
      setLoginLoading(false);
      setShowLoginModal(false);
      setIsCustomLogin(false);
      setVerifyingUser(null);
      setEnteredPin("");
      
      // Reset custom fields
      setCustomName("");
      setCustomEmail("");
      setCustomNip("");
      setCustomJabatan("");
    }, 1200);
  };

  const handleLogout = () => {
    if (confirm("Apakah Anda yakin ingin keluar dari Akun Google Dinas Anda?")) {
      setCurrentUser(null);
      localStorage.removeItem("siaap_lapor_auth_session");
      setShowAddForm(false);
    }
  };

  // Fetch activities from Express backend & perform bidirectional sync
  const fetchActivities = async () => {
    setLoading(true);
    setErrorStatus(null);
    setSyncStatus("syncing");
    try {
      const res = await fetch("/api/activities");
      if (!res.ok) throw new Error("Gagal mengunduh daftar kegiatan.");
      let serverData = await res.json() as Kegiatan[];
      
      const localDataStr = localStorage.getItem("siaap_lapor_activities_v1");
      if (localDataStr) {
        const localData = JSON.parse(localDataStr) as Kegiatan[];
        
        // Find items in LocalStorage that are marked as offline pending
        const pendingUploads = localData.filter((item) => item.isOfflinePending === true);

        if (pendingUploads.length > 0) {
          console.log(`Menemukan ${pendingUploads.length} laporan offline yang belum tersinkronisasi. Menyelaraskan ke server...`);
          
          for (const item of pendingUploads) {
            try {
              const cleanPayload = { ...item };
              delete cleanPayload.isOfflinePending;

              await fetch("/api/activities", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(cleanPayload),
              });
              
              // Mark as successfully uploaded locally
              item.isOfflinePending = false;
            } catch (syncErr) {
              console.error("Gagal sinkronisasi otomatis item offline:", item.id, syncErr);
            }
          }

          // Fetch the updated, fully merged database list from the server
          const refreshedRes = await fetch("/api/activities");
          if (refreshedRes.ok) {
            serverData = await refreshedRes.json() as Kegiatan[];
          }
        }
        
        // Final merged list: only keep items that are still waiting for offline upload, plus official server records
        const activeOfflinePending = pendingUploads.filter((item) => item.isOfflinePending === true);
        const merged = [...activeOfflinePending, ...serverData];
        
        // Deduplicate
        const uniqueMerged: Kegiatan[] = [];
        const seenIds = new Set<string>();
        for (const item of merged) {
          if (!seenIds.has(item.id)) {
            uniqueMerged.push(item);
            seenIds.add(item.id);
          }
        }

        setActivities(uniqueMerged);
        localStorage.setItem("siaap_lapor_activities_v1", JSON.stringify(uniqueMerged));
      } else {
        setActivities(serverData);
        localStorage.setItem("siaap_lapor_activities_v1", JSON.stringify(serverData));
      }
      setSyncStatus("connected");
    } catch (err: any) {
      console.error(err);
      setSyncStatus("offline");
      const localDataStr = localStorage.getItem("siaap_lapor_activities_v1");
      if (localDataStr) {
        setActivities(JSON.parse(localDataStr));
      } else {
        setErrorStatus("Gagal menyambung ke server lokal. Berjalan dalam mode offline.");
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchActivities();
  }, []);

  // Filter list real-time
  const filteredList = filterKegiatan(activities, searchQuery, dateFilter);

  // Reset page to 1 when search or date filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, dateFilter]);

  const totalItems = filteredList.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  // Guard the current page
  const safeCurrentPage = Math.min(Math.max(1, currentPage), totalPages || 1);
  const startIndex = (safeCurrentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedList = filteredList.slice(startIndex, endIndex);

  // Derived dashboard stats
  const totalFilteredCount = filteredList.length;
  // Badge Hijau is for completed/saved activities count (status === "Terlapor")
  const totalTerlaporCount = filteredList.filter((x) => x.status === "Terlapor").length;
  const totalDraftCount = filteredList.filter((x) => x.status === "Draft").length;

  // Handle saving new report
  const handleSaveNewReport = async (payload: Omit<Kegiatan, "id">) => {
    setLoading(true);
    try {
      // Create local item with temporary ID to write immediately
      const tempId = "act_" + Date.now() + "_" + Math.floor(Math.random() * 1000);
      const newLocalItem: Kegiatan = {
        ...payload,
        id: tempId,
        isOfflinePending: true,
      };

      // Add to local state and local storage immediately
      const currentLocal = JSON.parse(localStorage.getItem("siaap_lapor_activities_v1") || "[]") as Kegiatan[];
      const updatedLocal = [newLocalItem, ...currentLocal];
      localStorage.setItem("siaap_lapor_activities_v1", JSON.stringify(updatedLocal));
      setActivities(updatedLocal);

      // Post to server API
      const res = await fetch("/api/activities", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Gagal menyimpan ke server.");
      }

      const savedItem = await res.json();
      
      // Replace temporary item with DB official item
      const finalLocal = JSON.parse(localStorage.getItem("siaap_lapor_activities_v1") || "[]") as Kegiatan[];
      const replacedIdx = finalLocal.findIndex(x => x.id === tempId);
      if (replacedIdx !== -1) {
        finalLocal[replacedIdx] = savedItem;
      } else {
        finalLocal.unshift(savedItem);
      }
      localStorage.setItem("siaap_lapor_activities_v1", JSON.stringify(finalLocal));
      setActivities(finalLocal);
      
      setShowAddForm(false);
    } catch (err: any) {
      console.error(err);
      alert(`Catatan: Laporan disimpan offline di penjelajah internet (browser) Anda. Gagal sinkronisasi ke server: ${err.message || err}`);
      setShowAddForm(false);
    } finally {
      setLoading(false);
    }
  };

  // Safe individual activity deletion
  const handleDeleteActivity = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();

    // Verifikasi otoritas Hapus berdasarkan Email
    const userEmail = currentUser?.email || "";
    const isAllowed = ALLOWED_DELETE_EMAILS.includes(userEmail.toLowerCase());

    if (!isAllowed) {
      alert("Maaf, Anda tidak memiliki otoritas (Akses Administrator) untuk melakukan penghapusan data.");
      return;
    }

    if (!confirm("Apakah Anda yakin ingin menghapus arsip Laporan Kegiatan ini secara permanen?")) {
      return;
    }

    // Immediately remove from local storage & state so the UI is responsive and independent of server resets
    const currentLocal = JSON.parse(localStorage.getItem("siaap_lapor_activities_v1") || "[]") as Kegiatan[];
    const updatedLocal = currentLocal.filter(x => x.id !== id);
    localStorage.setItem("siaap_lapor_activities_v1", JSON.stringify(updatedLocal));
    setActivities(updatedLocal);
    if (expandedId === id) setExpandedId(null);

    try {
      const res = await fetch(`/api/activities/${id}`, {
        method: "DELETE",
      });
      if (!res.ok) {
        console.warn("Laporan terhapus dari browser, gagal menghapus di server database.");
      }
    } catch (err) {
      console.error("Gagal menghapus di server:", err);
    }
  };

  // Launch edit state (allows edit of Name, NIP, Jabatan & Resume)
  const startInlineEditing = (item: Kegiatan, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(item.id);
    setEditName(item.namaPelaksana);
    setEditNip(item.nip || "");
    setEditJabatan(item.jabatan || "");
    setEditResume(item.resumeOriginal);
    setInlineError(null);
  };

  const cancelInlineEditing = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(null);
    setInlineError(null);
  };

  // Save modified name, NIP, Jabatan and resume and trigger auto AI summary regeneration
  // If saveAsNew is true, we create a new separate activity instead of overwriting the existing one!
  const handleSaveInlineEdit = async (item: Kegiatan, saveAsNew: boolean, e: React.MouseEvent) => {
    e.stopPropagation();
    setInlineError(null);

    const targetName = editName.trim();
    const targetNip = editNip.trim();
    const targetJabatan = editJabatan.trim();
    const targetResume = editResume.trim();

    if (!targetName) {
      setInlineError("Nama Pelaksana Tugas tidak boleh kosong.");
      return;
    }
    if (!targetResume) {
      setInlineError("Catatan poin resume kegiatan tidak boleh kosong.");
      return;
    }

    setIsUpdatingAI(true);
    try {
      // 1. Regenerate Gemini summary based on the updated points
      const sumRes = await fetch("/api/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resumeOriginal: targetResume,
          judulKegiatan: item.judulKegiatan,
          namaPelaksana: targetName,
          jabatan: targetJabatan,
        }),
      });

      let updatedSummary = item.resumeGenerated;
      if (sumRes.ok) {
        const sumData = await sumRes.json();
        updatedSummary = sumData.summary;
      } else {
        console.warn("AI summarize failed during update. Keeping old summary or default.");
        // Fallback local paragraph generator
        const cleanOriginal = targetResume
          .split(/[.\n]+/)
          .map((s) => s.trim())
          .filter((s) => s.length > 0);
        let joinedPoints = cleanOriginal.join(". Selain itu, dibahas pula ");
        if (joinedPoints) {
          joinedPoints = "terangkum beberapa poin pembahasan utama yaitu " + joinedPoints + ".";
        } else {
          joinedPoints = "pembahasan berjalan lancar dan menghasilkan koordinasi yang sinergis.";
        }
        updatedSummary = `KABUPATEN POHUWATO — Mengenai agenda "${item.judulKegiatan}", berikut adalah ringkasan hasil kegiatan secara sederhana dan objektif.\n\nTerkait jalannya kegiatan tersebut, ${joinedPoints} Hasil pembahasan ini diserap sebagai acuan peningkatan pelayanan publik serta koordinasi berkelanjutan di lingkungan kerja Pemerintah Kabupaten Pohuwato.\n\n*(Catatan: Mode Demo Aktif. Pasang GEMINI_API_KEY di panel Secrets untuk hasil jurnalisme kecerdasan buatan berkualitas tinggi).*`;
      }

      // 2. Incremental or New object
      const newId = saveAsNew 
        ? "act_" + Date.now() + "_" + Math.floor(Math.random() * 1000) 
        : item.id;

      const newEditCount = saveAsNew 
        ? 0 
        : (item.editCount || 0) + 1;

      const updatedItem: Kegiatan = {
        ...item,
        id: newId,
        namaPelaksana: targetName,
        nip: targetNip || "-",
        jabatan: targetJabatan || "Fungsional",
        resumeOriginal: targetResume,
        resumeGenerated: updatedSummary,
        status: "Terlapor", // Automatically promote to Terlapor status
        editCount: newEditCount,
      };

      // 3. Immediately save to local storage & state so there's no lag or data loss
      const currentLocal = JSON.parse(localStorage.getItem("siaap_lapor_activities_v1") || "[]") as Kegiatan[];
      let updatedLocal: Kegiatan[] = [];
      if (saveAsNew) {
        updatedLocal = [updatedItem, ...currentLocal];
      } else {
        updatedLocal = currentLocal.map(x => x.id === item.id ? updatedItem : x);
      }
      localStorage.setItem("siaap_lapor_activities_v1", JSON.stringify(updatedLocal));
      setActivities(updatedLocal);

      setEditingId(null);
      setExpandedId(updatedItem.id);

      // 4. Match with server db
      if (saveAsNew) {
        try {
          const postRes = await fetch("/api/activities", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedItem),
          });
          if (!postRes.ok) {
            console.warn("Gagal menyinkronkan laporan tambahan baru ke server.");
          }
        } catch (postErr) {
          console.error("Gagal POST ke server database:", postErr);
        }
      } else {
        try {
          const putRes = await fetch(`/api/activities/${item.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedItem),
          });

          if (!putRes.ok) {
            console.warn("Gagal menyinkronkan pembaruan edit ke server database.");
          }
        } catch (putErr) {
          console.error("Gagal PUT ke server database:", putErr);
        }
      }
    } catch (err: any) {
      setInlineError(err.message || "Gagal memperbarui data.");
    } finally {
      setIsUpdatingAI(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans antialiased text-slate-800 pb-20">
      
      {/* UPPER PREMIUM TEAL OFF-GRID HEADER CONTAINER */}
      <header className="bg-gradient-to-r from-teal-700 via-teal-800 to-slate-900 text-white shadow-lg border-b-2 border-teal-600 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="p-1.5 rounded-lg bg-white shadow-xs border border-teal-500/20 flex items-center justify-center">
              <img 
                src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj19y1_X-QqZ4yM0NzFEb-hm0K6fB1eR6TmlnyYdtRxgRhTpfTPcZbZXP8Sg78Mz3f-_3oktY2K7SR5wPimzSr2NnJxUT9F6CRZAZEwZYR7gF_nrueI4negUTlmLMFK4j7lsShsjVP0jPJGKQoFfCDNtS-D4Kb8rGMSJ67cZMd_Wry3H7ga7fHYTKISEffe/s1600/logo_app.png" 
                alt="Logo Pohuwato" 
                className="w-9 h-9 object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h1 className="text-xl font-black uppercase tracking-wider font-sans flex items-center gap-2">
                SIAAP LAPOR
                {syncStatus === "syncing" && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[9px] font-bold tracking-normal normal-case bg-amber-500 text-amber-950 rounded-full animate-pulse">
                    <RefreshCw className="w-2.5 h-2.5 animate-spin" />
                    Sinkronisasi...
                  </span>
                )}
                {syncStatus === "connected" && (
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 text-[9px] font-bold tracking-normal normal-case bg-emerald-500/20 text-emerald-300 border border-emerald-500/35 rounded-full">
                    <span className="relative flex h-1.5 w-1.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                    </span>
                    Sinkron Hybrid
                  </span>
                )}
                {syncStatus === "offline" && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[9px] font-bold tracking-normal normal-case bg-rose-500/20 text-rose-300 border border-rose-500/35 rounded-full">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                    Offline Lokal
                  </span>
                )}
              </h1>
              <p className="text-xs text-teal-200">
                Sistem Pelaporan Kegiatan / Perjalanan Kedinasan
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Primary Command: Tambah Laporan */}
            <button
              onClick={() => {
                if (currentUser) {
                  setShowAddForm(true);
                } else {
                  setShowLoginModal(true);
                }
              }}
              className="px-4 py-2.5 bg-teal-500 hover:bg-teal-400 text-teal-950 text-xs font-bold uppercase rounded shadow transition-all flex items-center gap-1.5 focus:ring-2 focus:ring-teal-300 active:scale-95 cursor-pointer"
              id="btn-add-report-top"
            >
              <Plus className="w-4 h-4 text-teal-950 font-bold" />
              Laporan Baru
            </button>

            {/* Primary Command: Cetak Rekap */}
            {currentUser && (
              <button
                onClick={() => setShowRekapPrint(true)}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase rounded shadow transition-all flex items-center gap-1.5 focus:ring-2 focus:ring-blue-300 active:scale-95 cursor-pointer"
                id="btn-rekap-top"
              >
                <Printer className="w-4 h-4" />
                Cetak Rekap (Tabel)
              </button>
            )}

            {/* Google Authentication Segment */}
            {currentUser ? (
              <div className="flex items-center gap-3 bg-white/10 pl-3.5 pr-2 py-1 rounded-lg border border-teal-500/25">
                <div className="text-right leading-none hidden md:block">
                  <div className="text-xs font-bold text-teal-100">{currentUser.name}</div>
                  <div className="text-[10px] text-teal-300/80 font-mono mt-0.5 truncate max-w-[160px]">{currentUser.jabatan}</div>
                </div>
                {currentUser.avatarUrl ? (
                  <img 
                    src={currentUser.avatarUrl} 
                    alt={currentUser.name} 
                    className="w-8 h-8 rounded-full border border-teal-400 object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-teal-600 text-white font-bold text-xs flex items-center justify-center border border-teal-450">
                    {currentUser.name.charAt(0)}
                  </div>
                )}
                <button
                  onClick={handleLogout}
                  className="p-1.5 px-2 bg-teal-900/60 hover:bg-teal-900 text-teal-200 border border-teal-700/30 text-[10px] font-bold uppercase tracking-wider rounded transition-all flex items-center gap-1 cursor-pointer"
                >
                  <LogOut className="w-3 h-3 text-teal-300" />
                  Keluar
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowLoginModal(true)}
                className="px-3.5 py-2 bg-slate-950 hover:bg-slate-900 border border-slate-700 text-slate-100 rounded text-xs font-bold transition-all flex items-center gap-2 shadow-md cursor-pointer active:scale-95"
              >
                <img 
                  src="https://www.gstatic.com/images/branding/product/1x/gsa_512dp.png" 
                  alt="Google" 
                  className="w-4 h-4 shrink-0"
                />
                <span className="hidden sm:inline">Masuk Google</span>
                <span className="inline sm:hidden">Masuk</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* CORE WRAPPER container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6 grid grid-cols-1 gap-6 print:p-0 print:m-0">
        
        {/* PUBLIC MODE DISCLOSURE BANNER */}
        {!currentUser && (
          <div className="bg-amber-500/10 border border-amber-500/25 rounded-xl p-4 flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between shadow-xs">
            <div className="flex gap-2.5 items-start">
              <Lock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold text-amber-900 uppercase">Akses Terbatas (Belum Login)</h4>
                <p className="text-xs text-amber-800 mt-0.5 leading-relaxed">
                  Anda saat ini sedang berselancar sebagai Publik. Demi menjaga integritas data arsip, Anda hanya diperbolehkan melihat ringkasan baris Daftar Laporan saja. Seluruh fitur perluas baris, detail laporan, pencetakan PDF, dan manipulasi data terkunci sampai Anda melakukan Masuk dengan Google.
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowLoginModal(true)}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded text-xs font-bold flex items-center gap-1.5 self-end sm:self-center shrink-0 shadow-sm cursor-pointer transition-colors"
            >
              <LogIn className="w-3.5 h-3.5" />
              Masuk Google
            </button>
          </div>
        )}
        
        {/* UPPER STATUS REVENUE-LIKE SUMMARY TILES (Rangkuman Digital Real-Time) */}
        <section className="grid grid-cols-1 sm:grid-cols-3 gap-4 print:hidden" id="stats-dashboard">
          {/* Tile 1: Total Ter-filter */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex items-center justify-between">
            <div>
              <span className="block text-xs font-bold text-slate-400 uppercase tracking-widest">Saringan Aktif</span>
              <span className="block text-2xl font-black text-slate-800 mt-1 font-mono">{totalFilteredCount}</span>
              <span className="text-[10px] text-slate-500">Arsip kegiatan lolos filter</span>
            </div>
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-500">
              <Filter className="w-5 h-5" />
            </div>
          </div>

          {/* Tile 2: Terlapor (GREEN BADGE HIGHLIGHTS) */}
          <div className="bg-emerald-50 rounded-xl shadow-sm border border-emerald-100 p-4 flex items-center justify-between">
            <div>
              <span className="block text-xs font-bold text-emerald-800 uppercase tracking-widest">Terkirim / Terlapor</span>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-2xl font-black text-emerald-950 font-mono">{totalTerlaporCount}</span>
                <span className="px-2 py-0.5 text-[9px] font-bold uppercase bg-emerald-600 text-white rounded-full">
                  Badge Hijau
                </span>
              </div>
              <span className="text-[10px] text-emerald-700">Telah divalidasi & diarsipkan</span>
            </div>
            <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
              <FileText className="w-5 h-5" />
            </div>
          </div>

          {/* Tile 3: Draft (YELLOW ACENTS) */}
          <div className="bg-amber-50 rounded-xl shadow-sm border border-amber-100 p-4 flex items-center justify-between">
            <div>
              <span className="block text-xs font-bold text-amber-800 uppercase tracking-widest">Arsip Draft</span>
              <span className="block text-2xl font-black text-amber-950 mt-1 font-mono">{totalDraftCount}</span>
              <span className="text-[10px] text-amber-700">Masih dapat diedit penuh</span>
            </div>
            <div className="w-12 h-12 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
              <AlertCircle className="w-5 h-5" />
            </div>
          </div>
        </section>

        {/* COLLAPSIBLE QUICK SEARCH & FILTERS PANELS */}
        <section className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden print:hidden" id="filters-container">
          
          {/* Filter Header bar */}
          <div 
            onClick={() => setIsFilterCollapsed(!isFilterCollapsed)}
            className="px-5 py-3.5 bg-slate-100 border-b border-slate-200 flex justify-between items-center cursor-pointer select-none hover:bg-slate-150/50"
          >
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-teal-700" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-teal-950">Panel Cari & Filter Cepat Laporan</h3>
            </div>
            <div className="text-slate-500">
              {isFilterCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
            </div>
          </div>

          {/* Collapsible area body */}
          {!isFilterCollapsed && (
            <div className="p-5 grid grid-cols-1 md:grid-cols-3 gap-4">
              
              {/* Keyword Search */}
              <div className="md:col-span-2 space-y-1">
                <label className="block text-[11px] font-bold text-slate-600 uppercase">Cari Berdasarkan Kata Kunci</label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Ketik judul kegiatan, pelaksana, lokasi, rujukan hukum, atau poin dinas..."
                    className="w-full pl-9 pr-4 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 text-slate-800"
                    id="search-realtime-input"
                  />
                </div>
              </div>

              {/* Date Filter Selection */}
              <div className="space-y-1">
                <label className="block text-[11px] font-bold text-slate-600 uppercase">Filter Berdasarkan Rentang Kalender</label>
                <div className="grid grid-cols-12 gap-1 bg-slate-100 p-0.5 rounded border border-slate-200">
                  <button
                    onClick={() => setDateFilter("all")}
                    className={`col-span-3 py-1.5 text-xs font-semibold rounded cursor-pointer ${
                      dateFilter === "all" ? "bg-white text-teal-800 shadow-xs" : "text-slate-500 hover:text-slate-800"
                    }`}
                  >
                    Semua
                  </button>
                  <button
                    onClick={() => setDateFilter("today")}
                    className={`col-span-3 py-1.5 text-xs font-semibold rounded cursor-pointer ${
                      dateFilter === "today" ? "bg-white text-teal-800 shadow-xs" : "text-slate-500 hover:text-slate-800"
                    }`}
                    title="Filtrasi laporan yang dilaporkan hari ini"
                  >
                    Hari Ini
                  </button>
                  <button
                    onClick={() => setDateFilter("yesterday")}
                    className={`col-span-3 py-1.5 text-xs font-semibold rounded cursor-pointer ${
                      dateFilter === "yesterday" ? "bg-white text-teal-800 shadow-xs" : "text-slate-500 hover:text-slate-800"
                    }`}
                    title="Filtrasi laporan kemarin"
                  >
                    Kemarin
                  </button>
                  <button
                    onClick={() => setDateFilter("this_week")}
                    className={`col-span-3 py-1.5 text-xs font-semibold rounded cursor-pointer ${
                      dateFilter === "this_week" ? "bg-white text-teal-800 shadow-xs" : "text-slate-500 hover:text-slate-800"
                    }`}
                    title="Pekan Pelaporan Berjalan"
                  >
                    Pekan Ini
                  </button>
                </div>
              </div>

            </div>
          )}
        </section>

        {/* Dynamic add form view container (If visible, masks dashboard with a full input screen) */}
        {showAddForm && (
          <section className="print:hidden">
            <ReportForm 
              onSave={handleSaveNewReport}
              onCancel={() => setShowAddForm(false)}
              isSaving={loading}
              initialUser={currentUser ? {
                name: currentUser.name,
                jabatan: currentUser.jabatan,
                nip: currentUser.nip
              } : undefined}
            />
          </section>
        )}

        {/* CORE DATABASE LIST SECTION */}
        {!showAddForm && (
          <section className="space-y-4 print:hidden" id="report-inventory-list">
            <div className="flex justify-between items-center px-1">
              <div>
                <h2 className="font-bold text-sm text-slate-700 tracking-wide uppercase">Daftar Laporan Ter-Arsip ({filteredList.length === 0 ? "0" : `${startIndex + 1}-${Math.min(endIndex, totalItems)} dari ${totalItems}`})</h2>
                <p className="text-[11px] text-slate-400">Pilih baris kegiatan di bawah ini untuk melihat detail lengkap regulasi, foto lampiran, dan naskah pers.</p>
              </div>
              <button
                onClick={fetchActivities}
                className="p-1 px-2.5 bg-slate-200 text-slate-700 text-xs font-semibold rounded flex items-center gap-1 hover:bg-slate-300"
                title="Muat ulang dari database"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Refresh
              </button>
            </div>

            {loading && activities.length === 0 ? (
              <div className="bg-white rounded-xl py-12 text-center text-slate-500 border border-slate-200">
                <div className="w-8 h-8 rounded-full border-2 border-teal-600 border-t-transparent animate-spin mx-auto mb-2"></div>
                <p className="text-xs font-medium">Melakukan asimilasi database lokal...</p>
              </div>
            ) : errorStatus ? (
              <div className="bg-red-50 text-red-900 border border-red-200 rounded-xl p-6 text-center">
                <AlertCircle className="w-8 h-8 text-red-600 mx-auto mb-2" />
                <p className="font-bold text-sm">Masalah Koneksi Server:</p>
                <p className="text-xs mt-1 text-red-700">{errorStatus}</p>
                <button
                  onClick={fetchActivities}
                  className="mt-3 px-4 py-1.5 bg-red-600 text-white rounded text-xs font-semibold"
                >
                  Hubungkan Ulang
                </button>
              </div>
            ) : filteredList.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-xl py-16 text-center text-slate-400">
                <FileText className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                <p className="font-bold text-sm text-slate-600">Tidak Menemukan Laporan Kegiatan</p>
                <p className="text-xs max-w-xs mx-auto text-slate-400 mt-1">
                  Harap sesuaikan frase cari katakunci atau ganti saringan tanggal untuk melihat kegiatan lain.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery("");
                    setDateFilter("all");
                  }}
                  className="mt-3 text-xs text-teal-700 font-bold underline"
                >
                  Reset Semua Filter Saringan
                </button>
              </div>
            ) : (
              <>
                {/* ARSIP ARTIKEL ROW/GRIDS list */}
                <div className="space-y-3.5">
                {paginatedList.map((item) => {
                  const isExpanded = !!currentUser && expandedId === item.id;
                  const isEditingThis = editingId === item.id;
                  const sameTitleCount = activities.filter(
                    (a) => a.judulKegiatan.trim().toLowerCase() === item.judulKegiatan.trim().toLowerCase()
                  ).length;

                  return (
                    <div 
                      key={item.id}
                      className={`bg-white rounded-xl shadow-xs border transition-all duration-300 ${
                        isExpanded ? "border-teal-400/80 ring-2 ring-teal-500/10" : "border-slate-200"
                      } ${currentUser ? "hover:border-slate-300" : ""}`}
                      id={`card-kegiatan-${item.id}`}
                    >
                      {/* CARD COMPACT HEADER ROW */}
                      <div 
                        onClick={() => {
                          if (currentUser) {
                            setExpandedId(isExpanded ? null : item.id);
                          }
                        }}
                        className={`p-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 select-none ${
                          currentUser ? "cursor-pointer" : "cursor-default"
                        }`}
                      >
                        <div className="flex-1 space-y-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className={`inline-flex px-2 py-0.5 rounded text-[10px] font-bold ${
                              item.status === "Terlapor" 
                                ? "bg-green-100 text-green-700 font-bold" 
                                : "bg-amber-100 text-amber-700 font-medium"
                            }`}>
                              ● {item.status}
                            </span>
                            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest bg-slate-100 px-1.5 py-0.5 rounded">
                              ID: SPK-{item.id.substring(4, 9).toUpperCase()}
                            </span>
                            <span className="text-xs text-slate-500 flex items-center gap-1">
                              <Calendar className="w-3.5 h-3.5 text-teal-600" />
                              Laporan: {item.tanggalLapor}
                            </span>
                            {item.editCount !== undefined && item.editCount > 0 && (
                              <span className="inline-flex items-center gap-1 text-[10px] bg-sky-50 text-sky-700 border border-sky-200 px-2 py-0.5 rounded font-bold">
                                ✏️ edit: {item.editCount}kali
                              </span>
                            )}
                            {sameTitleCount > 1 && (
                              <span className="inline-flex items-center gap-1 text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-100 px-2 py-0.5 rounded font-bold" title="Jumlah laporan personil dengan nama kegiatan yang sama">
                                👥 {sameTitleCount} pelaksana
                              </span>
                            )}
                          </div>

                          <h3 className="font-bold text-slate-800 text-base leading-snug hover:text-teal-800">
                            {item.judulKegiatan}
                          </h3>

                          <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
                            <span className="flex items-center gap-1">
                              <User className="w-3.5 h-3.5 text-slate-400" />
                              Pelaksana: <strong className="text-slate-700">{item.namaPelaksana}</strong> ({item.jabatan})
                            </span>
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3.5 h-3.5 text-slate-400" />
                              Lokasi: {item.lokasi}
                            </span>
                          </div>
                        </div>

                        {/* Top-Right fast Actions */}
                        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center" onClick={(e) => e.stopPropagation()}>
                          
                          {/* EDIT TRIGGER (Only Nama Pelaksana & Resume editable directly) */}
                          {currentUser && !isEditingThis && (
                            <button
                              onClick={(e) => startInlineEditing(item, e)}
                              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 hover:text-slate-900 rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
                              title="Hanya edit Nama Pelaksana Tugas dan Resume Lapangan kemudian simpan kembali"
                              id={`btn-edit-inline-${item.id}`}
                            >
                              <Edit2 className="w-3 h-3" />
                              Edit
                            </button>
                          )}

                          {/* Quick print PDF */}
                          {currentUser && (
                            <button
                              onClick={() => setCurrentPrintActivity(item)}
                              className="px-2.5 py-1.5 bg-teal-50 hover:bg-teal-100 border border-teal-200 text-teal-800 rounded text-xs font-bold flex items-center gap-1 cursor-pointer"
                              id={`btn-print-pdf-${item.id}`}
                            >
                              <Printer className="w-3 h-3" />
                              PDF
                            </button>
                          )}

                          {/* Fast delete */}
                          {currentUser && ALLOWED_DELETE_EMAILS.includes((currentUser.email || "").toLowerCase()) && (
                            <button
                              onClick={(e) => handleDeleteActivity(item.id, e)}
                              className="p-1 px-2 border border-red-200 bg-red-50 text-red-600 hover:bg-red-100 rounded cursor-pointer"
                              title="Hapus permanen"
                              id={`btn-delete-${item.id}`}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {currentUser && (
                            <div className="text-slate-400 pl-1 p-1">
                              {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                            </div>
                          )}

                        </div>
                      </div>

                      {/* CARD DETAILS EXPANDABLE SECTION */}
                      {isExpanded && (
                        <div className="px-5 pb-5 border-t border-slate-100 pt-4 bg-slate-50/40 space-y-5 rounded-b-xl">
                          
                          {/* INLINE EDIT MODE WRAPPER COOPERATIVE */}
                          {isEditingThis ? (
                            <div className="bg-white border border-teal-200 rounded-lg p-5 space-y-4 shadow-xs" id={`edit-box-card-${item.id}`}>
                              <div className="bg-slate-50 -m-5 mb-4 p-4 rounded-t-lg border-b border-slate-200 flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                                <div>
                                  <span className="font-bold text-xs uppercase tracking-wider text-teal-800 flex items-center gap-1.5">
                                    <Edit2 className="w-4 h-4 text-teal-600" />
                                    Penyuntingan Laporan & Identitas Pelapor
                                  </span>
                                  <p className="text-[10px] text-slate-500 mt-0.5">
                                    Anda dapat memperbarui identitas personil pelapor atau mendaftarkan pelapor tambahan baru untuk kegiatan ini.
                                  </p>
                                </div>
                                <span className="self-start sm:self-center text-[9px] bg-teal-800 text-teal-100 px-2 py-1 rounded font-mono uppercase tracking-wider font-extrabold">
                                  Mode Editor Dinas
                                </span>
                              </div>

                              {inlineError && (
                                <div className="p-3 bg-red-50 border-l-4 border-red-500 rounded text-red-950 text-xs flex gap-2 items-center">
                                  <AlertCircle className="w-4 h-4 shrink-0" />
                                  <span>{inlineError}</span>
                                </div>
                              )}

                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                {/* Column 1: Identitas Pelaksana */}
                                <div className="md:col-span-1 space-y-3 bg-slate-50/50 p-3.5 rounded-lg border border-slate-100">
                                  <h4 className="font-bold text-xs text-slate-700 uppercase tracking-wider border-b pb-1">Identitas Pelapor</h4>
                                  
                                  <div className="space-y-1">
                                    <label className="block text-[11px] font-bold text-slate-600">Nama Pelaksana Tugas *</label>
                                    <input 
                                      type="text"
                                      value={editName}
                                      onChange={(e) => setEditName(e.target.value)}
                                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 text-slate-800 font-medium"
                                      placeholder="Contoh: Hendra Wijaya, ST"
                                      id={`edit-nama-pelaksana-${item.id}`}
                                    />
                                  </div>

                                  <div className="space-y-1">
                                    <label className="block text-[11px] font-bold text-slate-600">NIP Pelaksana *</label>
                                    <input 
                                      type="text"
                                      value={editNip}
                                      onChange={(e) => setEditNip(e.target.value)}
                                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 text-slate-800"
                                      placeholder="NIP Pelaksana, e.g. 1993..."
                                      id={`edit-nip-${item.id}`}
                                    />
                                  </div>

                                  <div className="space-y-1">
                                    <label className="block text-[11px] font-bold text-slate-600">Jabatan Pelaksana *</label>
                                    <input 
                                      type="text"
                                      value={editJabatan}
                                      onChange={(e) => setEditJabatan(e.target.value)}
                                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 text-slate-800"
                                      placeholder="Contoh: Pengelola Monev"
                                      id={`edit-jabatan-${item.id}`}
                                    />
                                  </div>
                                </div>

                                {/* Column 2: Resume Content */}
                                <div className="md:col-span-2 space-y-3 bg-slate-50/50 p-3.5 rounded-lg border border-slate-100 flex flex-col justify-between">
                                  <div className="space-y-1 flex-1 flex flex-col">
                                    <div className="flex justify-between items-center border-b pb-1">
                                      <h4 className="font-bold text-xs text-slate-700 uppercase tracking-wider">Poin Resume Lapangan (Original) *</h4>
                                    </div>
                                    <textarea
                                      value={editResume}
                                      onChange={(e) => setEditResume(e.target.value)}
                                      className="w-full p-3 text-xs bg-white border border-slate-300 rounded font-mono focus:outline-none focus:ring-1.5 focus:ring-teal-500 text-slate-800 flex-1 mt-2 min-h-[140px]"
                                      placeholder="Masukkan poin-poin kegiatan dinas lapangan..."
                                      id={`edit-resume-original-${item.id}`}
                                    />
                                  </div>
                                  <p className="text-[10px] text-slate-400 mt-1">
                                    💡 Mengubah poin di atas akan mengaktifkan jurnalisme kecerdasan buatan Gemini AI untuk merangkas ulang dokumen laporan secara otomatis secara elegan.
                                  </p>
                                </div>
                              </div>

                              {/* Explanation Box of saving options */}
                              <div className="p-3 bg-teal-50/50 border border-teal-100 rounded-lg text-xs text-teal-900 space-y-1">
                                <p className="font-bold flex items-center gap-1 text-[11px]">
                                  💡 Opsi Alur Penyimpanan Data Pelaporan:
                                </p>
                                <ul className="list-disc pl-4 text-[10.5px] text-teal-800 space-y-0.5">
                                  <li><strong>Simpan sebagai Laporan Tambahan Baru:</strong> Membuat laporan terpisah baru untuk pendamping/peserta lain dengan nama & jabatan yang baru diedit di atas. Ini akan menambah jumlah data resmi di dashboard kabupaten secara otomatis.</li>
                                </ul>
                              </div>

                              <div className="flex flex-col sm:flex-row justify-between items-center gap-3 border-t border-slate-100 pt-3">
                                <button
                                  onClick={cancelInlineEditing}
                                  className="w-full sm:w-auto px-4 py-2 border border-slate-300 text-slate-700 rounded text-xs font-semibold hover:bg-slate-100 cursor-pointer text-center"
                                >
                                  Batal
                                </button>
                                
                                <div className="w-full sm:w-auto flex flex-col sm:flex-row gap-2">
                                  <button
                                    onClick={(e) => handleSaveInlineEdit(item, true, e)}
                                    disabled={isUpdatingAI}
                                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-bold flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer shadow-xs"
                                    id={`btn-inline-save-new-trigger-${item.id}`}
                                  >
                                    <Plus className="w-3.5 h-3.5" />
                                    {isUpdatingAI ? "Proses..." : "Simpan sebagai Laporan Tambahan Baru"}
                                  </button>
                                </div>
                              </div>
                            </div>
                          ) : (
                            // DEFAULT DETAILED READ-ONLY EXPANDED GRAPHIC
                            <div className="grid grid-cols-1 md:grid-cols-12 gap-5" id={`detail-row-${item.id}`}>
                              {/* Left detail Column: Lists, Dates, Regulations */}
                              <div className="md:col-span-5 space-y-4">
                                <div className="bg-white p-3.5 rounded-lg border border-slate-200/80 space-y-2.5">
                                  <h4 className="font-bold text-xs uppercase text-slate-500 tracking-wider">Durasi & Jadwal Agenda</h4>
                                  <div className="text-xs space-y-1 text-slate-700 font-medium">
                                    <p>Mulai: <strong className="text-slate-900">{formatLabelDate(item.startDate)}</strong></p>
                                    <p>Selesai: <strong className="text-slate-900">{formatLabelDate(item.endDate)}</strong></p>
                                    <p>Waktu Kerja: <strong className="text-slate-900">{item.startTime} s/d {item.endTime} WIB</strong></p>
                                  </div>
                                </div>

                                <div className="bg-white p-3.5 rounded-lg border border-slate-200/80 space-y-2">
                                  <h4 className="font-bold text-xs uppercase text-slate-500 tracking-wider">I. Dasar Pelaksanaan (Regulasi)</h4>
                                  <ul className="text-xs space-y-1.5 text-slate-700 list-none pl-1">
                                    {item.regulasi && item.regulasi.length > 0 ? (
                                      item.regulasi.map((reg, idx) => (
                                        <li key={idx} className="flex gap-2 items-start leading-relaxed text-slate-700">
                                          <span className="font-bold text-teal-700">{idx + 1}.</span>
                                          <span>{reg}</span>
                                        </li>
                                      ))
                                    ) : (
                                      <p className="italic text-slate-400">Tidak ada landasan hukum.</p>
                                    )}
                                  </ul>
                                </div>

                                <div className="bg-white p-3.5 rounded-lg border border-slate-200/80 space-y-2">
                                  <h4 className="font-bold text-xs uppercase text-slate-500 tracking-wider">Metode Data Point Masukan</h4>
                                  <p className="text-xs text-slate-600 font-mono leading-relaxed whitespace-pre-wrap rounded bg-slate-50 p-2 border border-slate-100">
                                    {item.resumeOriginal}
                                  </p>
                                </div>
                              </div>

                              {/* Right detail Column: Gemini text paragraph & Photo carousels */}
                              <div className="md:col-span-7 space-y-4">
                                {/* Gemini output */}
                                <div className="bg-teal-50/20 border border-teal-100 rounded-lg p-4 space-y-2">
                                  <div className="flex justify-between items-center border-b border-teal-100 pb-1.5">
                                    <h4 className="font-bold text-xs uppercase text-teal-900 flex items-center gap-1">
                                      <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                                      Hasil Saringan Pers (Based on AI)
                                    </h4>
                                    <span className="text-[9px] bg-teal-800 text-white px-2 py-0.5 rounded font-mono">
                                      Official Print
                                    </span>
                                  </div>
                                  <p className="text-xs leading-relaxed text-slate-700 text-justify whitespace-pre-wrap">
                                    {item.resumeGenerated || "Belum terdapat narasi berita jurnalis."}
                                  </p>
                                </div>

                                {/* Thumbnail previews */}
                                {item.images && item.images.length > 0 && (
                                  <div className="space-y-1.5">
                                    <h4 className="font-bold text-xs uppercase text-slate-500 tracking-wider">
                                      Foto Bukti Lapangan ({item.images.length} Gambar) - PDF: "sebagaimana terlampir"
                                    </h4>
                                    <div className="grid grid-cols-4 gap-2">
                                      {item.images.map((src, imgIdx) => (
                                        <div key={imgIdx} className="border border-slate-200 rounded p-0.5 bg-white shadow-xs">
                                          <img
                                            src={src}
                                            alt={`Dokumentasi ${imgIdx + 1}`}
                                            className="w-full h-14 object-cover rounded cursor-pointer hover:opacity-90"
                                            onClick={() => setCurrentPrintActivity(item)}
                                            title="Klik untuk cetak penuh"
                                          />
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}

                        </div>
                      )}

                    </div>
                  );
                })}
              </div>

              {/* PAGINATION ENGINE & CONTROLLER */}
              {totalItems > 0 && (
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white border border-slate-200 rounded-xl p-4 mt-5 shadow-xs" id="pagination-controls">
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span>Tampilkan:</span>
                    <select
                      value={itemsPerPage}
                      onChange={(e) => {
                        setItemsPerPage(Number(e.target.value));
                        setCurrentPage(1);
                      }}
                      className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1 text-slate-700 font-semibold focus:ring-1 focus:ring-teal-500 focus:outline-none cursor-pointer"
                    >
                      <option value={5}>5 Baris</option>
                      <option value={10}>10 Baris</option>
                      <option value={20}>20 Baris</option>
                      <option value={50}>50 Baris</option>
                      <option value={100}>100 Baris</option>
                    </select>
                    <span className="ml-1 text-slate-600">
                      Menampilkan <strong className="text-slate-800">{totalItems === 0 ? 0 : startIndex + 1}</strong> hingga <strong className="text-slate-800">{Math.min(endIndex, totalItems)}</strong> dari <strong className="text-slate-800">{totalItems}</strong> baris data
                    </span>
                  </div>
                  
                  {totalPages > 1 && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                        disabled={safeCurrentPage === 1}
                        className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1 transition-all ${
                          safeCurrentPage === 1
                            ? "bg-slate-50 text-slate-300 border-slate-100 cursor-not-allowed"
                            : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50 active:bg-slate-100 hover:border-slate-300"
                        }`}
                      >
                        ‹ Prev
                      </button>
                      
                      {/* Page Numbers */}
                      <div className="flex items-center gap-1 mx-1">
                        {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => {
                          // Show ellipsis if too many pages
                          if (
                            totalPages > 5 &&
                            pageNum !== 1 &&
                            pageNum !== totalPages &&
                            Math.abs(pageNum - safeCurrentPage) > 1
                          ) {
                            if (pageNum === 2 && safeCurrentPage > 3) {
                              return <span key="ellipsis-start" className="text-xs text-slate-400 px-1 font-mono">...</span>;
                            }
                            if (pageNum === totalPages - 1 && safeCurrentPage < totalPages - 2) {
                              return <span key="ellipsis-end" className="text-xs text-slate-400 px-1 font-mono">...</span>;
                            }
                            return null;
                          }
                          
                          return (
                            <button
                              key={pageNum}
                              onClick={() => setCurrentPage(pageNum)}
                              className={`w-8 h-8 rounded-lg text-xs font-semibold border transition-all ${
                                safeCurrentPage === pageNum
                                  ? "bg-teal-700 text-white border-teal-600 shadow-sm font-bold"
                                  : "bg-white text-slate-600 border-slate-100 hover:bg-teal-50 hover:text-teal-900 hover:border-teal-200"
                              }`}
                            >
                              {pageNum}
                            </button>
                          );
                        })}
                      </div>
                      
                      <button
                        onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                        disabled={safeCurrentPage === totalPages}
                        className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1 transition-all ${
                          safeCurrentPage === totalPages
                            ? "bg-slate-50 text-slate-300 border-slate-100 cursor-not-allowed"
                            : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50 active:bg-slate-100 hover:border-slate-300"
                        }`}
                      >
                        Next ›
                      </button>
                    </div>
                  )}
                </div>
              )}
              </>
            )}
          </section>
        )}

      </main>

      {/* FOOTER */}
      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 mb-6 text-center text-xs text-slate-400 font-sans print:hidden" id="app-system-footer">
        <p>@bapppedapohuwato-2026 | Penggunaan internal</p>
      </footer>

      {/* POPUP VIEW MODALS: INDIVIDUAL PRINT SLAB PREVIEW */}
      {currentPrintActivity && (() => {
        const sortedActivities = [...activities].sort((a, b) => {
          const dateA = a.startDate + " " + a.startTime;
          const dateB = b.startDate + " " + b.startTime;
          return dateA.localeCompare(dateB);
        });
        const idx = sortedActivities.findIndex(item => item.id === currentPrintActivity.id);
        const sequenceNum = String(idx !== -1 ? idx + 1 : 1).padStart(3, '0');

        return (
          <ReportPrintView 
            activity={currentPrintActivity}
            nomorUrut={sequenceNum}
            onClose={() => setCurrentPrintActivity(null)}
            userEmail={currentUser?.email || undefined}
          />
        );
      })()}

      {/* POPUP VIEW MODALS: GLOBAL FILTERED SPREADSHEET REKAP PREVIEW */}
      {showRekapPrint && (
        <GlobalRekapPrintView 
          currentList={filteredList}
          onClose={() => setShowRekapPrint(false)}
        />
      )}

      {/* GOOGLE SIGN-IN GOV SIMULATION MODAL */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4" id="google-auth-portal">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-250/60 flex flex-col transition-all">
            
            {/* Modal Navigation header */}
            <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div className="flex items-center gap-1.5 text-slate-500 font-mono text-[9px] uppercase font-bold tracking-wider">
                <img 
                  src="https://www.gstatic.com/images/branding/product/1x/gsa_512dp.png" 
                  alt="Google" 
                  className="w-4 h-4"
                />
                Google Identity Hub
              </div>
              <button 
                onClick={() => {
                  setShowLoginModal(false);
                  setIsCustomLogin(false);
                  setVerifyingUser(null);
                  setWhitelistError("");
                  setPinError("");
                }}
                className="p-1 rounded-full text-slate-400 hover:bg-slate-200 hover:text-slate-600 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {loginLoading ? (
              /* PROGRESS SPINNER ENGINE */
              <div className="py-24 px-8 text-center space-y-4 flex flex-col items-center justify-center">
                <div className="inline-block relative w-12 h-12">
                  <div className="absolute inset-0 rounded-full border-4 border-slate-100"></div>
                  <div className="absolute inset-0 rounded-full border-4 border-blue-600 border-t-transparent animate-spin"></div>
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-sm text-slate-700">Menghubungkan Akun Google...</h4>
                  <p className="text-xs text-slate-400">Memverifikasi otentikasi aman terintegrasi Kabupaten Pohuwato</p>
                </div>
              </div>
            ) : verifyingUser ? (
              /* SECURE PIN VERIFICATION PANEL */
              <form onSubmit={handleVerifyPinSubmit} className="p-6 sm:p-8 space-y-6">
                <div className="text-center space-y-3">
                  <div className="relative inline-block">
                    {verifyingUser.avatarUrl ? (
                      <img 
                        src={verifyingUser.avatarUrl} 
                        alt={verifyingUser.name} 
                        className="w-16 h-16 rounded-full object-cover border-2 border-blue-500 mx-auto"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-full bg-blue-100 text-blue-700 font-extrabold text-xl flex items-center justify-center border-2 border-blue-200 mx-auto">
                        {verifyingUser.name.charAt(0)}
                      </div>
                    )}
                    <div className="absolute -bottom-1 -right-1 bg-blue-600 text-white p-1 rounded-full border border-white flex items-center justify-center">
                      <Lock className="w-3 h-3" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-md font-extrabold text-slate-800">{verifyingUser.name}</h3>
                    <p className="text-xs font-mono text-slate-400">{verifyingUser.email}</p>
                    <span className="text-[10px] bg-slate-100 text-slate-600 inline-block px-2 py-0.5 rounded font-semibold mt-1">{verifyingUser.jabatan}</span>
                  </div>
                </div>

                <div className="p-4 bg-blue-50/50 border border-blue-100 rounded-xl space-y-1 text-center">
                  <h4 className="font-bold text-xs text-blue-900 flex items-center justify-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-blue-600" />
                    Verifikasi Keamanan 2-Langkah
                  </h4>
                  <p className="text-[11px] text-slate-600 leading-normal">
                    Masukkan 6-digit PIN Otorisasi / Sandi Dinas Anda untuk mengonfirmasi akses Anda ke sistem.
                  </p>
                </div>

                {pinError && (
                  <div className="p-3 bg-red-50 border border-red-200 text-red-650 rounded-xl text-xs flex items-center gap-2 font-medium">
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                    <span>{pinError}</span>
                  </div>
                )}

                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider text-center">Sandi / PIN Keamanan (6 Digit)</label>
                  <input
                    type="password"
                    maxLength={6}
                    required
                    autoFocus
                    value={enteredPin}
                    onChange={(e) => {
                      setPinError("");
                      setEnteredPin(e.target.value.replace(/\D/g, "")); // only numbers
                    }}
                    placeholder="••••••"
                    className="w-full text-center tracking-[1em] text-lg font-bold px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white text-slate-800"
                  />
                </div>

                <div className="flex gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setVerifyingUser(null);
                      setEnteredPin("");
                      setPinError("");
                    }}
                    className="flex-1 py-2.5 text-xs font-semibold border border-slate-250 hover:bg-slate-50 rounded-xl transition-all cursor-pointer text-slate-700 text-center"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer text-center"
                  >
                    Verifikasi & Masuk
                  </button>
                </div>
              </form>
            ) : !isCustomLogin ? (
              /* REALISTIC MICROSOFT & GOOGLE STYLE ACCOUNT CHOOSER panel */
              <div className="p-6 sm:p-8 space-y-6">
                <div className="text-center space-y-2.5">
                  <img 
                    src="https://www.gstatic.com/images/branding/product/1x/gsa_512dp.png" 
                    alt="Google Logo" 
                    className="w-11 h-11 mx-auto"
                  />
                  <div>
                    <h3 className="text-lg font-extrabold text-slate-800 tracking-tight font-sans">Masuk dengan Google</h3>
                    <p className="text-xs text-slate-500 mt-1">Pilih akun Pemerintah Kabupaten Pohuwato untuk melanjutkan ke SIAAP LAPOR</p>
                  </div>
                </div>

                <div className="space-y-2.5">
                  {DEMO_ACCOUNTS.map((acc, key) => {
                    const isAdmin = ALLOWED_DELETE_EMAILS.includes((acc.email || "").toLowerCase());
                    return (
                      <button
                        key={key}
                        onClick={() => handleSelectAccount(acc)}
                        className="w-full p-3 border border-slate-200 rounded-xl hover:bg-slate-50/70 hover:border-slate-300 text-left flex items-center gap-3 transition-all text-slate-700 group cursor-pointer active:scale-[0.98]"
                      >
                        {acc.avatarUrl ? (
                          <img 
                            src={acc.avatarUrl} 
                            alt={acc.name} 
                            className="w-10 h-10 rounded-full object-cover border border-slate-150 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-700 font-extrabold text-sm flex items-center justify-center border border-blue-200 shrink-0">
                            {acc.name.charAt(0)}
                          </div>
                        )}
                        <div className="flex-1 leading-snug overflow-hidden">
                          <div className="font-bold text-xs text-slate-800 group-hover:text-blue-600 transition-colors truncate">{acc.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono truncate">{acc.email}</div>
                          <div className="flex flex-wrap gap-1 mt-1">
                            <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-semibold">{acc.jabatan}</span>
                            {isAdmin && (
                              <span className="text-[9px] bg-red-50 text-red-600 border border-red-150 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">Akses Admin</span>
                            )}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>

                <div className="pt-2 border-t border-slate-100">
                  <button
                    onClick={() => {
                      setIsCustomLogin(true);
                      setWhitelistError("");
                    }}
                    className="w-full py-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-250 hover:border-slate-300 rounded-xl text-slate-700 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <User className="w-4 h-4 text-slate-550" />
                    Gunakan Akun Google ASN Lain
                  </button>
                </div>
              </div>
            ) : (
              /* GENERAL PERSONEL REGISTRATION INPUT FORM */
              <form onSubmit={handleCustomLoginSubmit} className="p-6 sm:p-8 space-y-4">
                <div className="text-center space-y-1">
                  <img 
                    src="https://www.gstatic.com/images/branding/product/1x/gsa_512dp.png" 
                    alt="Google Logo" 
                    className="w-9 h-9 mx-auto"
                  />
                  <h3 className="text-md font-extrabold text-slate-800 tracking-tight">Login Google Pegawai</h3>
                  <p className="text-[10.5px] text-slate-400">Konfigurasi akun kedinasan Anda melalui sistem koordinat Google Identity</p>
                </div>

                {whitelistError && (
                  <div className="p-3 bg-red-50 border border-red-150 rounded-xl text-[11px] text-red-650 leading-relaxed flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <span>{whitelistError}</span>
                  </div>
                )}

                <div className="space-y-3">
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Nama Lengkap & Gelar *</label>
                    <input
                      type="text"
                      required
                      value={customName}
                      onChange={(e) => setCustomName(e.target.value)}
                      placeholder="Contoh: Rony Hermawan, ST"
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Email Kedinasan *</label>
                    <input
                      type="email"
                      required
                      value={customEmail}
                      onChange={(e) => {
                        setWhitelistError("");
                        setCustomEmail(e.target.value);
                      }}
                      placeholder="username@pohuwato.go.id atau gmail Anda yang terdaftar"
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
                    />
                    <p className="text-[9.5px] text-slate-400 italic">Harus sesuai dengan email yang terdaftar resmi pada whitelist sistem.</p>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">NIP Pegawai *</label>
                      <input
                        type="text"
                        required
                        value={customNip}
                        onChange={(e) => setCustomNip(e.target.value)}
                        placeholder="19xxxxxxxxxxxxxx"
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Jabatan *</label>
                      <input
                        type="text"
                        required
                        value={customJabatan}
                        onChange={(e) => setCustomJabatan(e.target.value)}
                        placeholder="Contoh: Kepala Bidang Infraswil"
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-2.5 pt-3">
                  <button
                    type="button"
                    onClick={() => {
                      setIsCustomLogin(false);
                      setWhitelistError("");
                    }}
                    className="flex-1 py-2 text-xs font-semibold border border-slate-250 hover:bg-slate-50 rounded-lg transition-all cursor-pointer text-slate-700 text-center"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer text-center"
                  >
                    Sign In Google
                  </button>
                </div>
              </form>
            )}

            {/* Auth terms policy footer */}
            <div className="p-3 bg-slate-50 text-[10.5px] text-slate-400 text-center border-t border-slate-100 flex items-center justify-center gap-3">
              <span>Google Kebijakan Privasi</span>
              <span>•</span>
              <span>Ketentuan Layanan</span>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
