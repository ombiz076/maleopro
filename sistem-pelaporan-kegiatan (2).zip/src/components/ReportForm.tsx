import React, { useState, useRef, useEffect } from "react";
import { 
  User, Award, FileText, Calendar, Clock, MapPin, 
  Plus, Trash2, Sparkles, Upload, AlertCircle, Save, X, Image as ImageIcon, CheckCircle
} from "lucide-react";
import { compressImage, getLockedIndonesianDate } from "../utils";

interface ReportFormProps {
  onSave: (data: {
    namaPelaksana: string;
    jabatan: string;
    nip: string;
    judulKegiatan: string;
    startDate: string;
    endDate: string;
    startTime: string;
    endTime: string;
    lokasi: string;
    tanggalLapor: string;
    regulasi: string[];
    resumeOriginal: string;
    resumeGenerated: string;
    images: string[];
    status: "Draft" | "Terlapor";
  }) => Promise<void>;
  onCancel: () => void;
  isSaving: boolean;
  initialUser?: {
    name: string;
    jabatan?: string;
    nip?: string;
  };
}

export default function ReportForm({ onSave, onCancel, isSaving, initialUser }: ReportFormProps) {
  // Dynamically calculate today's date in local time YYYY-MM-DD
  const todayObj = new Date();
  const year = todayObj.getFullYear();
  const month = String(todayObj.getMonth() + 1).padStart(2, "0");
  const day = String(todayObj.getDate()).padStart(2, "0");
  const todayStr = `${year}-${month}-${day}`;

  // Today representation (locked)
  const lockedDate = getLockedIndonesianDate(todayObj);

  // State I: Informasi Awal
  const [namaPelaksana, setNamaPelaksana] = useState(initialUser?.name || "");
  const [jabatan, setJabatan] = useState(initialUser?.jabatan || "");
  const [nip, setNip] = useState(initialUser?.nip || "");
  const [judulKegiatan, setJudulKegiatan] = useState("");
  const [startDate, setStartDate] = useState(todayStr);
  const [endDate, setEndDate] = useState(todayStr);
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("12:00");
  const [lokasi, setLokasi] = useState("");

  // State II: Informasi Kegiatan - Regulasi
  const [regulasiList, setRegulasiList] = useState<string[]>([
    "Undang-Undang Nomor 23 Tahun 2014 tentang Pemerintahan Daerah"
  ]);

  // State II: Informasi Kegiatan - Resume Point Form & AI Paragraph
  const [resumeOriginal, setResumeOriginal] = useState("");
  const [resumeGenerated, setResumeGenerated] = useState("");
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [aiGeneratedSuccess, setAiGeneratedSuccess] = useState(false);

  // State II: Dokumentasi Foto (base64)
  const [images, setImages] = useState<string[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [compressingState, setCompressingState] = useState(false);

  // Material-like Validations State
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-generate AI preview if points change significantly (optional, or user triggered)
  const handleGenerateAI = async () => {
    if (!resumeOriginal.trim()) {
      setValidationErrors(["Resume Kegiatan (catatan poin-poin) harus diisi dahulu sebelum dapat dirangkum oleh AI."]);
      return;
    }
    if (!judulKegiatan.trim()) {
      setValidationErrors(["Silakan isi Judul Kegiatan terlebih dahulu agar AI dapat memahami konteks penulisan."]);
      return;
    }

    setIsGeneratingAI(true);
    setValidationErrors([]);
    try {
      const res = await fetch("/api/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resumeOriginal,
          judulKegiatan,
          namaPelaksana: namaPelaksana || "Pelaksana Tugas",
          jabatan: jabatan || "Fungsional",
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setResumeGenerated(data.summary);
        setAiGeneratedSuccess(true);
      } else {
        throw new Error(data.error || "Gagal memperoleh rangkuman AI.");
      }
    } catch (err: any) {
      console.error(err);
      setValidationErrors([`Terjadi kesalahan integrasi AI : ${err.message || err}. Menggunakan modul kegagalan lokal.`]);
    } finally {
      setIsGeneratingAI(false);
    }
  };

  // Safe Regulasi array handlers
  const handleAddRegulasi = () => {
    setRegulasiList([...regulasiList, ""]);
  };

  const handleUpdateRegulasi = (index: number, val: string) => {
    const updated = [...regulasiList];
    updated[index] = val;
    setRegulasiList(updated);
  };

  const handleRemoveRegulasi = (index: number) => {
    const updated = regulasiList.filter((_, i) => i !== index);
    setRegulasiList(updated.length > 0 ? updated : [""]);
  };

  // Image Upload Core Logic with Drag-and-Drop + Click
  const processImageFiles = async (files: FileList) => {
    setValidationErrors([]);
    const availableSlots = 4 - images.length;
    if (availableSlots <= 0) {
      setValidationErrors(["Maksimal unggahan adalah 4 foto dokumen kegiatan."]);
      return;
    }

    setCompressingState(true);
    const loadedImages: string[] = [];

    // Limit intake to slots
    const filesToProcess = Array.from(files).slice(0, availableSlots);

    try {
      for (const file of filesToProcess) {
        if (!file.type.startsWith("image/")) {
          continue;
        }
        // Compress on the client-side
        const compressedBase64 = await compressImage(file);
        loadedImages.push(compressedBase64);
      }

      setImages((prev) => [...prev, ...loadedImages]);
    } catch (err) {
      console.error(err);
      setValidationErrors(["Gagal memuat atau mengompresi gambar. Coba format gambar JPEG/PNG lain."]);
    } finally {
      setCompressingState(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      processImageFiles(e.target.files);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files) {
      processImageFiles(e.dataTransfer.files);
    }
  };

  const handleRemoveImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  // Submit button click handler containing all constraints & material validation notices
  const handleSubmit = (statusValue: "Draft" | "Terlapor") => {
    const errors: string[] = [];

    if (!namaPelaksana.trim()) errors.push("Nama Pelaksana Tugas tidak boleh kosong (Informasi Awal).");
    if (!jabatan.trim()) errors.push("Jabatan Pelaksana wajib diisi.");
    if (!nip.trim()) errors.push("NIP Pelaksana wajib dicantumkan.");
    if (!judulKegiatan.trim()) errors.push("Judul Kegiatan tidak boleh kosong.");
    if (!lokasi.trim()) errors.push("Lokasi Kegiatan wajib dimasukkan.");
    
    // Check regulasi
    const validRegulasi = regulasiList.map(r => r.trim()).filter(r => r !== "");
    if (validRegulasi.length === 0) {
      errors.push("Rujukan Regulasi minimal diisi 1 peraturan dasar.");
    }

    if (!resumeOriginal.trim()) {
      errors.push("Resume Kegiatan (catatan poin-poin) wajib diisi untuk diulas.");
    }

    if (images.length < 2) {
      errors.push("Unggah Foto Dokumentasi minimal 2 foto. Saat ini: " + images.length + " foto.");
    }
    if (images.length > 4) {
      errors.push("Unggah Foto Dokumentasi maksimal 4 foto.");
    }

    if (errors.length > 0) {
      setValidationErrors(errors);
      // Auto scroll to validation area
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }

    // Process save with full metadata
    onSave({
      namaPelaksana: namaPelaksana.trim(),
      jabatan: jabatan.trim(),
      nip: nip.trim(),
      judulKegiatan: judulKegiatan.trim(),
      startDate,
      endDate,
      startTime,
      endTime,
      lokasi: lokasi.trim(),
      tanggalLapor: lockedDate,
      regulasi: validRegulasi,
      resumeOriginal: resumeOriginal.trim(),
      resumeGenerated: resumeGenerated.trim() || "Menunggu pembuatan narasi formal oleh editor.",
      images,
      status: statusValue,
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-xl border border-teal-100 overflow-hidden text-slate-800" id="form-container">
      {/* Form Header */}
      <div className="bg-gradient-to-r from-teal-700 via-teal-800 to-slate-900 px-6 py-5 text-white flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold font-sans tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-teal-300" />
            Formulir Input Laporan Kegiatan Baru
          </h2>
          <p className="text-teal-200 text-xs mt-1">
            Harap isi semua tiga (3) bidang utama secara komprehensif untuk pelaporan formal.
          </p>
        </div>
        <button 
          onClick={onCancel}
          className="text-white/80 hover:text-white p-1.5 hover:bg-white/10 rounded-full transition-all"
          title="Tutup Formulir"
          id="btn-close-form"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Material Dynamic Warnings Card */}
      {validationErrors.length > 0 && (
        <div className="mx-6 mt-6 p-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg text-red-900 animate-pulse" id="alert-validation">
          <div className="flex gap-2.5 items-start">
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-sm">Peringatan Validasi Sistem:</p>
              <ul className="list-disc pl-5 mt-1 text-xs space-y-1">
                {validationErrors.map((err, i) => (
                  <li key={i}>{err}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      <div className="p-6 space-y-8">
        
        {/* ================= SECTION I: INFORMASI AWAL ================= */}
        <section className="space-y-4" id="section-informasi-awal">
          <div className="flex items-center gap-2 border-b border-teal-100 pb-2">
            <div className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 font-bold text-xs flex items-center justify-center">I</div>
            <h3 className="font-bold text-teal-900 text-sm tracking-wide uppercase">Bagian I: Informasi Awal Pelaksanaan</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Pelaksana Tugas */}
            <div className="md:col-span-3 bg-teal-50/50 p-4 rounded-lg border border-teal-100/70 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="col-span-1 md:col-span-3 font-semibold text-xs text-teal-950 uppercase tracking-widest flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-teal-600" />
                Data Pelaksana Tugas Resmi NIP-Kedinasan
              </div>
              
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Nama Lengkap Pelaksana *</label>
                <input 
                  type="text"
                  placeholder="Contoh: Hendra Wijaya, S.STP."
                  value={namaPelaksana}
                  onChange={(e) => setNamaPelaksana(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                  id="inp-nama-pelaksana"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Jabatan Fungsional *</label>
                <input 
                  type="text"
                  placeholder="Contoh: Kabid Infraswil"
                  value={jabatan}
                  onChange={(e) => setJabatan(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                  id="inp-jabatan-pelaksana"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Nomor Induk Pegawai (NIP) *</label>
                <input 
                  type="text"
                  placeholder="Contoh: 198812102010121002"
                  value={nip}
                  onChange={(e) => setNip(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                  id="inp-nip-pelaksana"
                />
              </div>
            </div>

            {/* Judul Kegiatan */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">Judul / Nama Agenda Kegiatan Dinas *</label>
              <input 
                type="text"
                placeholder="Contoh: Sosialisasi Penyediaan Sarana Air Bersih Kabupaten"
                value={judulKegiatan}
                onChange={(e) => setJudulKegiatan(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 font-medium"
                id="inp-judul-kegiatan"
              />
            </div>

            {/* Locked Tanggal Lapor */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Tanggal Laporan (Terkunci Otomatis)</label>
              <div className="px-3 py-2 text-sm bg-slate-100 border border-slate-300 rounded text-slate-500 font-semibold cursor-not-allowed flex items-center justify-between" id="locked-date-lapor">
                <span>{lockedDate}</span>
                <span className="text-[10px] bg-teal-700 text-white px-2 py-0.5 rounded uppercase">Locked</span>
              </div>
            </div>

            {/* Durasi (Range Tanggal) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Durasi Mulai (Start Date) *</label>
              <div className="relative">
                <Calendar className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400 pointer-events-none" />
                <input 
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 text-slate-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Durasi Selesai (End Date) *</label>
              <div className="relative">
                <Calendar className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400 pointer-events-none" />
                <input 
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 text-slate-600"
                />
              </div>
            </div>

            {/* Lokasi */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Lokasi Agenda Pelaksanaan *</label>
              <div className="relative">
                <MapPin className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400 pointer-events-none" />
                <input 
                  type="text"
                  placeholder="Contoh: Aula Kelurahan"
                  value={lokasi}
                  onChange={(e) => setLokasi(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                />
              </div>
            </div>

            {/* Range Waktu */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Waktu Jam Mulai *</label>
              <div className="relative">
                <Clock className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400 pointer-events-none" />
                <input 
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 text-slate-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Waktu Jam Selesai *</label>
              <div className="relative">
                <Clock className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400 pointer-events-none" />
                <input 
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 text-slate-600"
                />
              </div>
            </div>

          </div>
        </section>

        {/* ================= SECTION II: INFORMASI KEGIATAN ================= */}
        <section className="space-y-6" id="section-informasi-kegiatan">
          <div className="flex items-center gap-2 border-b border-teal-100 pb-2">
            <div className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 font-bold text-xs flex items-center justify-center">II</div>
            <h3 className="font-bold text-teal-900 text-sm tracking-wide uppercase">Bagian II: Informasi Rincian Kegiatan</h3>
          </div>

          {/* 1. Rujukan Regulasi (Numbering) */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
            <div className="flex justify-between items-center mb-3">
              <div>
                <h4 className="font-bold text-slate-700 text-sm">1. Rujukan Regulasi Daerah / Landasan Hukum</h4>
                <p className="text-[11px] text-slate-500 mt-0.5">Disesuaikan otomatis dalam penomoran .</p>
              </div>
              <button
                type="button"
                onClick={handleAddRegulasi}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-teal-600 hover:bg-teal-700 text-white rounded transition-colors"
                id="btn-add-regulasi"
              >
                <Plus className="w-3.5 h-3.5" />
                Tambah Rujukan
              </button>
            </div>

            <div className="space-y-2">
              {regulasiList.map((reg, index) => (
                <div key={index} className="flex gap-2 items-center">
                  <span className="w-6 text-xs text-right font-bold text-slate-500">{index + 1}.</span>
                  <input
                    type="text"
                    value={reg}
                    onChange={(e) => handleUpdateRegulasi(index, e.target.value)}
                    placeholder="Contoh: Peraturan Menteri No. 130 Tahun 2018 tentang Pembangunan Kelurahan"
                    className="flex-1 px-3 py-1.5 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                  />
                  {regulasiList.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveRegulasi(index)}
                      className="text-red-500 hover:text-red-700 p-1 bg-white hover:bg-red-50 rounded border border-slate-200 transition-colors"
                      title="Hapus Baris regulasi"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* 2. Resume Kegiatan & AI Gemini Summarizer */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Input Points */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="block text-xs font-bold text-slate-700">
                  2. Poin-Poin Pokok Masukan (Resume Lapangan) *
                </label>
                <span className="text-[10px] text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">Mental Notes Only</span>
              </div>
              <textarea
                value={resumeOriginal}
                onChange={(e) => setResumeOriginal(e.target.value)}
                placeholder="Masukkan poin-poin mentah kegiatan di sini untuk diolah AI . Harap jelaskan misalnya:&#10;• Siapa yang hadir atau terlibat dalam kegiatan tersebut.&#10;• Siapa yang membuka kegiatan.&#10;• Siapa-siapa narasumbernya.&#10;• Dimana kegiatan dilaksanakan (diambil dari isian 'lokasi').&#10;• Mengapa kegiatan ini dilaksanakan.&#10;• Poin pembicaraan/hasil pembahasan dalam kegiatan tersebut."
                rows={6}
                className="w-full p-3 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 font-mono"
                id="txt-resume-original"
              />
              
              <button
                type="button"
                onClick={handleGenerateAI}
                disabled={isGeneratingAI}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-blue-600 via-teal-600 to-teal-700 hover:from-blue-700 hover:to-teal-800 text-white rounded font-bold text-sm shadow-md transition-all hover:shadow-lg origin-center disabled:opacity-50"
                id="btn-trigger-ai"
              >
                <Sparkles className={`w-4 h-4 ${isGeneratingAI ? "animate-spin" : ""}`} />
                {isGeneratingAI ? "Mengolah Data Jurnalistik Via AI..." : "Rangkum Poin Menjadi Narasi Formal"}
              </button>
            </div>

            {/* Generated AI Preview (Press release editorial) */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="block text-xs font-bold text-teal-950 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600 inline" />
                  Pratinjau Hasil Generated AI (Hasil Cetak PDF)
                </label>
                {aiGeneratedSuccess && (
                  <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded font-bold flex items-center gap-0.5">
                    <CheckCircle className="w-3 h-3" /> AI Siap
                  </span>
                )}
              </div>
              <div className="relative min-h-[150px] p-4 bg-slate-50 border border-slate-300 rounded-lg text-xs leading-relaxed text-slate-700 font-sans shadow-inner overflow-auto h-[178px] whitespace-pre-wrap" id="ai-preview-box">
                {resumeGenerated ? (
                  resumeGenerated
                ) : (
                  <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-slate-400 p-6">
                    <Sparkles className="w-8 h-8 text-slate-300 mb-2" />
                    <p className="font-semibold text-xs">Belum Ada Narasi Berita</p>
                    <p className="text-[11px] max-w-xs mt-1 text-slate-400">
                      Tulis poin mentah Anda di sebelah kiri lalu klik tombol peluncur AI di atas untuk menyusun narasi pers yang profesional.
                    </p>
                  </div>
                )}
              </div>
              <p className="text-[10px] text-slate-500 italic">
                * Catatan: Kalimat berita di atas akan langsung tercetak pada Bagian II Laporan Cetak PDF Anda.
              </p>
            </div>
          </div>

          {/* 3. Foto Dokumentasi */}
          <div className="bg-teal-50/30 p-5 rounded-lg border border-teal-100 space-y-4">
            <div>
              <h4 className="font-bold text-teal-900 text-sm flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-teal-700" />
                3. Foto Bukti Dokumentasi Kegiatan (Min 2, Maks 4) *
              </h4>
              <p className="text-xs text-teal-800 mt-1">
                Format landscape: JPEG, PNG, WEBP . Hasil cetak PDF dipisah halaman lampiran tersendiri khusus foto ("sebagaimana terlampir") berisi 2 gambar per halaman.
              </p>
            </div>

            {/* Drag & Drop File Upload Handler */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-all ${
                isDragging
                  ? "border-teal-500 bg-teal-100/50"
                  : "border-slate-300 hover:border-teal-500 bg-white"
              }`}
              id="file-dropzone"
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                multiple
                className="hidden"
              />
              <Upload className="mx-auto w-10 h-10 text-teal-600 mb-2" />
              <p className="font-semibold text-sm text-slate-700">Tarik gambar Anda kesini atau klik untuk menelusuri</p>
              <p className="text-xs text-slate-400 mt-1">Format landscape: JPEG, PNG, WEBP (maksimal sisa kuota: {4 - images.length} foto)</p>
            </div>

            {compressingState && (
              <div className="flex items-center gap-2 justify-center text-xs text-teal-700 font-semibold animate-pulse">
                <div className="w-3 h-3 bg-teal-600 rounded-full animate-bounce"></div>
                <span>Mengompresi Resolusi Gambar & Mengunggah...</span>
              </div>
            )}

            {/* Preview Grids of Compressed Image */}
            {images.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4" id="image-previews">
                {images.map((src, index) => (
                  <div key={index} className="relative group border border-teal-100 rounded bg-white p-1 shadow-sm">
                    <img
                      src={src}
                      alt={`Dokumen ${index + 1}`}
                      className="w-full h-24 object-cover rounded"
                    />
                    <div className="absolute top-1 right-1">
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(index)}
                        className="bg-red-500 text-white p-1 rounded-full hover:bg-red-700 transition-colors shadow"
                        title="Buang foto"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <span className="absolute bottom-1.5 left-1.5 text-[9px] bg-teal-800 text-white px-1.5 py-0.5 rounded font-mono">
                      Compressed
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Footer Actions / Submit Btns */}
        <div className="border-t border-slate-200 pt-6 flex flex-col sm:flex-row justify-end items-center gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="w-full sm:w-auto px-5 py-2 text-sm font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
          >
            Batal
          </button>
          
          <button
            type="button"
            onClick={() => handleSubmit("Draft")}
            disabled={isSaving}
            className="w-full sm:w-auto px-5 py-2 text-sm font-semibold text-blue-700 hover:text-blue-900 border border-blue-400 bg-blue-50/50 hover:bg-blue-50 rounded transition-colors disabled:opacity-50"
            id="btn-save-draft"
          >
            Simpan Sebagai Draft
          </button>

          <button
            type="button"
            onClick={() => handleSubmit("Terlapor")}
            disabled={isSaving}
            className="w-full sm:w-auto px-6 py-2 text-sm font-bold bg-teal-700 hover:bg-teal-800 text-white rounded shadow hover:shadow-md transition-colors inline-flex items-center gap-1.5 justify-center disabled:opacity-50"
            id="btn-save-terlapor"
          >
            <Save className="w-4 h-4" />
            Simpan & Kirim Laporan
          </button>
        </div>

      </div>
    </div>
  );
}
