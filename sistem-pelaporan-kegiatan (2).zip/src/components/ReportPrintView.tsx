import React from "react";
import { Kegiatan } from "../types";
import { formatLabelDate } from "../utils";
import { Printer, X, Download } from "lucide-react";

const deriveUserCode = (email?: string): string => {
  if (!email) return "BAP";
  const prefix = email.split("@")[0].toLowerCase();
  if (prefix === "humayraramadhani") return "HUM-BAP";
  if (prefix.includes("bapppeda") || prefix.includes("bappeda")) return "BAP";
  if (prefix.includes("admin")) return "ADM";
  if (prefix.includes("pohuwato")) return "PWH";
  // Clean alphanumeric upper case derived from email username
  const cleanStr = prefix.replace(/[^a-z0-9]/g, "").toUpperCase();
  return cleanStr.substring(0, 5) || "BAP";
};

interface ReportPrintViewProps {
  activity: Kegiatan;
  onClose: () => void;
  nomorUrut?: string;
  userEmail?: string;
}

export default function ReportPrintView({ activity, onClose, nomorUrut, userEmail }: ReportPrintViewProps) {
  const [showEditor, setShowEditor] = React.useState(false);
  const [settings, setSettings] = React.useState({
    pemerintah: "PEMERINTAH KABUPATEN POHUWATO",
    instansi: "BADAN PERENCANAAN,PENELITIAN DAN PENGEMBANGAN DAERAH",
    alamat: "Jalan M.H Thamrin, No.1, Blok Perkantoran Pemerintah Daerah",
    teleponEmail: "website : https://bapppeda.pohuwatokab.go.id/ | mail: bapppeda.pohuwato@gmail.com",
    logoType: 'uploaded' as 'none' | 'custom_text' | 'uploaded',
    logoText: "pohuwato",
    logoUrl: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj19y1_X-QqZ4yM0NzFEb-hm0K6fB1eR6TmlnyYdtRxgRhTpfTPcZbZXP8Sg78Mz3f-_3oktY2K7SR5wPimzSr2NnJxUT9F6CRZAZEwZYR7gF_nrueI4negUTlmLMFK4j7lsShsjVP0jPJGKQoFfCDNtS-D4Kb8rGMSJ67cZMd_Wry3H7ga7fHYTKISEffe/s1600/logo_app.png",
    suratSuffix: deriveUserCode(userEmail),
  });

  React.useEffect(() => {
    const saved = localStorage.getItem("kop_surat_settings");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.logoType === 'default') {
          parsed.logoType = 'none';
        }

        // Add or ensure default/existing suffix
        if (!parsed.suratSuffix) {
          parsed.suratSuffix = deriveUserCode(userEmail);
        }

        if (parsed.pemerintah === "PEMERINTAH KABUPATEN POHUWATO" || !parsed.pemerintah) {
          const freshDefaults = {
            pemerintah: "PEMERINTAH KABUPATEN POHUWATO",
            instansi: "BADAN PERENCANAAN,PENELITIAN DAN PENGEMBANGAN DAERAH",
            alamat: "Jalan M.H Thamrin, No.1, Blok Perkantoran Pemerintah Daerah",
            teleponEmail: "website : https://bapppeda.pohuwatokab.go.id/ | mail: bapppeda.pohuwato@gmail.com",
            logoType: 'uploaded' as 'none' | 'custom_text' | 'uploaded',
            logoText: "pohuwato",
            logoUrl: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj19y1_X-QqZ4yM0NzFEb-hm0K6fB1eR6TmlnyYdtRxgRhTpfTPcZbZXP8Sg78Mz3f-_3oktY2K7SR5wPimzSr2NnJxUT9F6CRZAZEwZYR7gF_nrueI4negUTlmLMFK4j7lsShsjVP0jPJGKQoFfCDNtS-D4Kb8rGMSJ67cZMd_Wry3H7ga7fHYTKISEffe/s1600/logo_app.png",
            suratSuffix: deriveUserCode(userEmail),
          };
          setSettings(freshDefaults);
          localStorage.setItem("kop_surat_settings", JSON.stringify(freshDefaults));
        } else {
          setSettings(parsed);
        }
      } catch (err) {
        console.error(err);
      }
    }
  }, [userEmail]);

  const saveSettings = (newSettings: typeof settings) => {
    setSettings(newSettings);
    localStorage.setItem("kop_surat_settings", JSON.stringify(newSettings));
    // Dispatch event to synchronize with rekap sheet if open
    window.dispatchEvent(new Event("kop_surat_changed"));
  };

  React.useEffect(() => {
    const handleSync = () => {
      const saved = localStorage.getItem("kop_surat_settings");
      if (saved) {
        try {
          setSettings(JSON.parse(saved));
        } catch (e) {}
      }
    };
    window.addEventListener("kop_surat_changed", handleSync);
    return () => window.removeEventListener("kop_surat_changed", handleSync);
  }, []);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        saveSettings({
          ...settings,
          logoType: 'uploaded',
          logoUrl: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  // Custom print trigger for browser window
  const handlePrintTrigger = () => {
    // Add print class helper and print
    window.print();
  };

  // Divide images into chunks of maximum 2 images per page for attachments
  const chunkImages = (arr: string[], size: number) => {
    const chunks = [];
    for (let i = 0; i < arr.length; i += size) {
      chunks.push(arr.slice(i, i + size));
    }
    return chunks;
  };

  const parts = activity.startDate ? activity.startDate.split("-") : ["2026", "05", "24"];
  const year = parts[0] || "2026";
  const month = parts[1] || "05";
  const indexStr = nomorUrut || activity.id.substring(4, 9).toUpperCase();
  const formatCode = settings.suratSuffix ? settings.suratSuffix.toUpperCase() : deriveUserCode(userEmail);
  const formattedNomor = `${indexStr}/SIAAP-LAPOR/${formatCode}/${month}/${year}`;

  const imagePages = chunkImages(activity.images || [], 2);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 py-10 px-4 flex flex-col items-center justify-start text-sans text-slate-800 backdrop-blur-xs print:p-0 print:bg-white print:overflow-visible print:static" id="print-modal">
      
      {/* CONFIGURATION PANEL (KOP SURAT MANAGER) */}
      <div className="w-full max-w-[210mm] bg-slate-800 text-white rounded-xl shadow-xl p-5 mb-4 print:hidden border border-slate-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-xl">🏢</span>
            <div>
              <h3 className="font-bold text-sm text-slate-100">⚙️ Atur Kop Surat & Logo</h3>
              <p className="text-[11px] text-slate-400">Ganti logo, nama instansi, NIP, atau rincian kop cetak untuk dinas Anda</p>
              <div className="mt-1.5 text-[10px] text-teal-400 font-medium bg-teal-950/40 px-2 py-0.5 rounded border border-teal-900/40 inline-block font-sans">
                💡 Sistem telah diset otomatis menyembunyikan header/footer browser. Jika browser Anda masih memunculkannya, hilangkan centang "Headers and footers" pada opsi cetak browser.
              </div>
            </div>
          </div>
          <button
            onClick={() => setShowEditor(!showEditor)}
            className="text-xs px-3 py-1.5 bg-slate-700 hover:bg-slate-600 rounded text-slate-200 transition-colors font-medium border border-slate-600"
          >
            {showEditor ? "Sembunyikan Pengaturan" : "Ganti Judul & Logo Dinas"}
          </button>
        </div>

        {showEditor && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-3 border-t border-slate-700 text-xs">
            <div className="space-y-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Tingkatan Pemerintah / Baris 1 (Kapital)</label>
                <input
                  type="text"
                  value={settings.pemerintah}
                  onChange={(e) => saveSettings({ ...settings, pemerintah: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-teal-500 uppercase"
                  placeholder="PEMERINTAH KABUPATEN SENTOSA"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Nama Dinas / Instansi / Baris 2 (Kapital)</label>
                <input
                  type="text"
                  value={settings.instansi}
                  onChange={(e) => saveSettings({ ...settings, instansi: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-teal-500 uppercase font-bold"
                  placeholder="DINAS KEPEGAWAIAN, INFRASTRUKTUR DAN PEMBANGUNAN DAERAH"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Alamat Instansi / Baris 3</label>
                <textarea
                  rows={2}
                  value={settings.alamat}
                  onChange={(e) => saveSettings({ ...settings, alamat: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  placeholder="Jalan Praja Utama No. 45, Kompleks..."
                />
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Kontak Dinas / Baris 4</label>
                <input
                  type="text"
                  value={settings.teleponEmail}
                  onChange={(e) => saveSettings({ ...settings, teleponEmail: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-teal-500 font-mono"
                  placeholder="Telepon: (021)... | Email: ..."
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Penyesuaian Logo</label>
                <div className="flex gap-2 mb-2">
                  <button
                    type="button"
                    onClick={() => saveSettings({ ...settings, logoType: 'none' })}
                    className={`flex-1 py-1 px-1.5 rounded text-[10px] font-semibold text-center border transition-all ${
                      settings.logoType === 'none'
                        ? 'bg-teal-700 text-white border-teal-600 shadow-inner'
                        : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    Tanpa Logo
                  </button>
                  <button
                    type="button"
                    onClick={() => saveSettings({ ...settings, logoType: 'custom_text' })}
                    className={`flex-1 py-1 px-1.5 rounded text-[10px] font-semibold text-center border transition-all ${
                      settings.logoType === 'custom_text'
                        ? 'bg-teal-700 text-white border-teal-600 shadow-inner'
                        : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    Teks Pendek
                  </button>
                  <button
                    type="button"
                    onClick={() => saveSettings({ ...settings, logoType: 'uploaded' })}
                    className={`flex-1 py-1 px-1.5 rounded text-[10px] font-semibold text-center border transition-all ${
                      settings.logoType === 'uploaded'
                        ? 'bg-teal-700 text-white border-teal-600 shadow-inner'
                        : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    Upload Gambar
                  </button>
                </div>

                {settings.logoType === 'custom_text' && (
                  <input
                    type="text"
                    maxLength={8}
                    value={settings.logoText}
                    onChange={(e) => saveSettings({ ...settings, logoText: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-teal-500 uppercase text-center font-bold font-mono tracking-widest text-[13px]"
                    placeholder="Contoh: PUPR"
                  />
                )}

                {settings.logoType === 'uploaded' && (
                  <div className="flex gap-2 items-center">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="w-full text-slate-300 file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:text-[10px] file:font-semibold file:bg-slate-700 file:text-slate-100 hover:file:bg-slate-600"
                    />
                    {settings.logoUrl && (
                      <div className="w-10 h-10 border border-slate-600 bg-white rounded flex items-center justify-center overflow-hidden shrink-0">
                        <img src={settings.logoUrl} alt="Preview" className="max-w-full max-h-full object-contain" />
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1 flex items-center justify-between">
                  <span>🔑 Kode Khusus Nomor Surat (Email-based)</span>
                  {userEmail && <span className="text-[10px] text-teal-400 normal-case font-mono">{userEmail}</span>}
                </label>
                <input
                  type="text"
                  maxLength={12}
                  value={settings.suratSuffix || ""}
                  onChange={(e) => saveSettings({ ...settings, suratSuffix: e.target.value.toUpperCase().replace(/[^A-Z0-9-]/g, "") })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-teal-500 uppercase font-mono text-[11px]"
                  placeholder="CONTOH: BAP-HUM"
                />
                <p className="text-[10px] text-slate-400 mt-1">Disisipkan secara otomatis sebagai kode unit/pelaksana nomor surat dinas Anda.</p>
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="button"
                  onClick={() => {
                    const defaults = {
                      pemerintah: "PEMERINTAH KABUPATEN POHUWATO",
                      instansi: "BADAN PERENCANAAN,PENELITIAN DAN PENGEMBANGAN DAERAH",
                      alamat: "Jalan M.H Thamrin, No.1, Blok Perkantoran Pemerintah Daerah",
                      teleponEmail: "website : https://bapppeda.pohuwatokab.go.id/ | mail: bapppeda.pohuwato@gmail.com",
                      logoType: 'uploaded' as 'none' | 'custom_text' | 'uploaded',
                      logoText: "pohuwato",
                      logoUrl: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj19y1_X-QqZ4yM0NzFEb-hm0K6fB1eR6TmlnyYdtRxgRhTpfTPcZbZXP8Sg78Mz3f-_3oktY2K7SR5wPimzSr2NnJxUT9F6CRZAZEwZYR7gF_nrueI4negUTlmLMFK4j7lsShsjVP0jPJGKQoFfCDNtS-D4Kb8rGMSJ67cZMd_Wry3H7ga7fHYTKISEffe/s1600/logo_app.png",
                      suratSuffix: deriveUserCode(userEmail),
                    };
                    saveSettings(defaults);
                  }}
                  className="px-2.5 py-1 text-[10px] text-red-400 hover:text-red-300 bg-red-950/40 hover:bg-red-950/60 font-semibold border border-red-900/60 rounded transition-colors"
                >
                  Kembalikan ke Default
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Printable Area Wrapper */}
      <div className="relative w-full max-w-[210mm] bg-white rounded-xl shadow-2xl p-8 mb-10 border border-slate-200 print:static print:border-none print:shadow-none print:p-0 print:m-0 print:max-w-none" id="printable-sheet">
        
        {/* Floating Print Command bar (Hidden during printing) */}
        <div className="absolute top-4 right-4 flex items-center gap-2 print:hidden" id="print-controls">
          <button
            onClick={handlePrintTrigger}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold rounded shadow transition-all hover:scale-105"
            title="Klik untuk Simpan ke PDF / Cetak"
          >
            <Printer className="w-4 h-4" />
            Cetak Laporan (PDF)
          </button>
          <button
            onClick={onClose}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 rounded-full transition-all"
            title="Tutup Pratinjau"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* ================= PAGE 1: CHIEF STATEMENT OF REPORT ================= */}
        <div className="print-page bg-white min-h-[297mm] p-6 print:p-0">
          
          {/* 1. KOP SURAT / LOGO OFFICIAL */}
          <div className="flex items-center gap-4 border-b-4 border-slate-900 pb-3 mb-6" id="kop-surat">
            {/* Logo placeholder */}
            {settings.logoType !== 'none' && (
              <div className="w-[75px] h-[75px] shrink-0 flex items-center justify-center">
                {settings.logoType === 'uploaded' && settings.logoUrl ? (
                  <img src={settings.logoUrl} alt="Logo Dinas" className="max-w-full max-h-full object-contain" />
                ) : settings.logoType === 'custom_text' ? (
                  <div className="w-[75px] h-[75px] bg-teal-800 text-white font-extrabold rounded-lg flex items-center justify-center border-2 border-teal-950 text-sm p-1 leading-tight text-center uppercase shadow-sm">
                    {settings.logoText || "LOGO"}
                  </div>
                ) : null}
              </div>
            )}
            
            <div className={`flex-1 text-center font-serif text-slate-900 ${settings.logoType !== 'none' ? 'pr-10' : ''}`}>
              <p className="text-sm font-bold tracking-widest uppercase">{settings.pemerintah}</p>
              <h1 className="text-[13px] font-extrabold tracking-wide uppercase" style={{ fontSize: "13px" }}>
                {settings.instansi}
              </h1>
              <p className="text-[10px] italic text-slate-500 font-sans tracking-tight leading-4">
                {settings.alamat}
                <br />
                {settings.teleponEmail}
              </p>
            </div>
          </div>

          <div className="text-center space-y-1 mb-6">
            <h2 className="text-[14px] font-extrabold uppercase tracking-wide text-slate-900 underline" style={{ fontSize: "14px" }}>
              LAPORAN KEGIATAN PERJALANAN KEDINASAN
            </h2>
            <p className="text-xs font-semibold text-slate-600 font-mono">
              Nomor: {formattedNomor}
            </p>
          </div>

          {/* 2. INFORMASI KEGIATAN TABLE-LIKE */}
          <div className="mb-4" id="informasi-kegiatan-pdf">
            <div className="grid grid-cols-12 gap-y-1 text-xs text-slate-900 leading-tight">
              <div className="col-span-3 font-semibold text-[12px] uppercase" style={{ fontSize: "12px" }}>
                Nama Kegiatan
              </div>
              <div className="col-span-9 flex">
                <span className="mr-2 font-semibold">:</span>
                <span className="flex-1 text-slate-800 font-sans font-medium">{activity.judulKegiatan}</span>
              </div>

              <div className="col-span-3 font-semibold text-[12px] uppercase" style={{ fontSize: "12px" }}>
                Jadual
              </div>
              <div className="col-span-9 flex">
                <span className="mr-2 font-semibold">:</span>
                <span className="flex-1 text-slate-800">
                  {activity.startDate === activity.endDate 
                    ? formatLabelDate(activity.startDate)
                    : `${formatLabelDate(activity.startDate)} s/d ${formatLabelDate(activity.endDate)}`
                  }
                </span>
              </div>

              <div className="col-span-3 font-semibold text-[12px] uppercase" style={{ fontSize: "12px" }}>
                Waktu
              </div>
              <div className="col-span-9 flex">
                <span className="mr-2 font-semibold">:</span>
                <span className="flex-1 text-slate-800">
                  {activity.startTime} s/d {activity.endTime} WITA
                </span>
              </div>

              <div className="col-span-3 font-semibold text-[12px] uppercase" style={{ fontSize: "12px" }}>
                Lokasi Kegiatan
              </div>
              <div className="col-span-9 flex">
                <span className="mr-2 font-semibold">:</span>
                <span className="flex-1 text-slate-800">{activity.lokasi}</span>
              </div>
            </div>
          </div>

          {/* thin border divider below head information */}
          <div className="border-b border-dashed border-slate-400 my-4"></div>

          {/* 3. ISI LAPORAN */}
          <div className="space-y-6 text-xs text-slate-800" id="isi-laporan-pdf">
            
            {/* I. Dasar Pelaksanaan */}
            <div>
              <h3 className="font-extrabold text-[12px] text-slate-900 uppercase mb-2 flex items-center" style={{ fontSize: "12px" }}>
                I. DASAR PELAKSANAAN
              </h3>
              <div className="pl-4 space-y-1">
                {activity.regulasi && activity.regulasi.length > 0 ? (
                  activity.regulasi.map((reg, idx) => (
                    <div key={idx} className="flex gap-2.5 items-start">
                      <span className="font-sans font-semibold min-w-[20px]">{idx + 1}.</span>
                      <span className="leading-relaxed">{reg}</span>
                    </div>
                  ))
                ) : (
                  <p className="italic text-slate-400">Tidak ada rujukan regulasi yang didaftarkan.</p>
                )}
              </div>
            </div>

            {/* II. Resume Kegiatan (AI Gemini Output) */}
            <div>
              <h3 className="font-extrabold text-[12px] text-slate-900 uppercase mb-2" style={{ fontSize: "12px" }}>
                II. RESUME KEGIATAN
              </h3>
              <div className="pl-4 text-justify leading-loose whitespace-pre-wrap font-sans text-slate-900" id="pdf-gemini-paragraf">
                {activity.resumeGenerated || "Belum dievaluasi oleh penyunting AI."}
              </div>
            </div>

            {/* III. Dokumentasi Foto Label */}
            <div>
              <h3 className="font-extrabold text-[12px] text-slate-900 uppercase mb-1" style={{ fontSize: "12px" }}>
                III. DOKUMENTASI FOTO
              </h3>
              <p className="pl-4 italic text-slate-600 font-sans">
                Sebagaimana Lampiran (Terlampir pada halaman pelengkap selanjutnya)
              </p>
            </div>

          </div>

          {/* 4. SIGNATURE SECTION */}
          <div className="mt-14 flex justify-end text-xs text-slate-900" id="signature-block">
            <div className="w-[280px] space-y-1 text-left">
              <p className="text-slate-600">Pohuwato, {activity.tanggalLapor}</p>
              <p className="font-bold text-slate-900 uppercase">Pelapor,</p>
              <p className="text-xs text-slate-700 font-medium leading-relaxed">{activity.jabatan}</p>
              
              {/* Spacing for sign */}
              <div className="h-16"></div>

              <div>
                <p className="font-extrabold text-slate-900 underline uppercase tracking-tight">
                  {activity.namaPelaksana}
                </p>
                <div className="border-b border-slate-300 w-full my-0.5"></div>
                <p className="text-[10px] italic font-sans" style={{ fontStyle: "italic" }}>
                  NIP. {activity.nip}
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* ================= PAGE(S) 2+: FOTO DOCUMENT PREVIEWS ================= */}
        {imagePages.map((pageImgs, pageIdx) => (
          <div 
            key={pageIdx} 
            className="print-page bg-white p-6 mt-10 border-t border-slate-200 pt-8 print:p-0 print:m-0 print:border-none print:pt-0"
            style={{ pageBreakBefore: "always", breakBefore: "page" }}
          >
            {/* Header lampiran */}
            <div className="text-center border-b-2 border-slate-900 pb-3 mb-8" id={`lampiran-header-${pageIdx}`}>
              <h3 className="text-sm font-extrabold tracking-widest uppercase text-slate-950">
                LAMPIRAN FOTO KEGIATAN
              </h3>
              <p className="text-[11px] text-slate-500 font-medium mt-1">
                Laporan Kegiatan-No: {formattedNomor} | Halaman Lampiran {pageIdx + 1} Dari {imagePages.length}
              </p>
            </div>

            {/* Grid display 2 pictures nicely sized stacked on Page */}
            <div className="space-y-6 flex flex-col items-center justify-center">
              {pageImgs.map((imgSrc, imgIdx) => (
                <div key={imgIdx} className="w-full max-w-[500px] border border-slate-300 rounded p-1 bg-white shadow-sm flex flex-col">
                  <img
                    src={imgSrc}
                    alt={`Dokumentasi Lapangan ${pageIdx * 2 + imgIdx + 1}`}
                    className="w-full h-[280px] object-cover rounded"
                  />
                  <div className="py-2.5 px-3 bg-slate-50 border-t border-slate-300 mt-1 flex justify-between items-center text-[10px] text-slate-600 font-semibold uppercase tracking-wider font-mono">
                    <span>FOTO DOKUMENTASI #{pageIdx * 2 + imgIdx + 1}</span>
                    <span>Tgl: {activity.startDate}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-10 text-center text-[10px] text-slate-400 italic">
              * Lampiran ini merupakan satu kesatuan tidak terpisahkan dari naskah laporan pertanggungjawaban asli.
            </div>
          </div>
        ))}

      </div>

      {/* Global CSS Inject Specifically for Printable Layout pages in high contrast A4 */}
      <style>{`
        @media print {
          @page {
            size: auto;
            margin: 0mm; /* Sembunyikan default header (Nama Sistem/Judul & Tanggal) & footer (Halaman & URL) bawaan browser */
          }
          body {
            visibility: hidden;
            background: white !important;
            margin: 0px !important;
          }
          #print-modal, #print-modal * {
            visibility: visible;
          }
          #printable-sheet, #printable-sheet * {
            visibility: visible;
          }
          #print-controls {
            display: none !important;
          }
          #print-modal {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            background: white !important;
            padding: 0 !important;
            margin: 0 !important;
            box-shadow: none !important;
            backdrop-filter: none !important;
            overflow: visible !important;
          }
          #printable-sheet {
            border: none !important;
            box-shadow: none !important;
            padding: 0 !important;
            margin: 0 !important;
            max-width: 100% !important;
            width: 100% !important;
          }
          .print-page {
            box-shadow: none !important;
            border: none !important;
            padding: 20mm !important; /* Cadangkan margin cetak resmi 2cm agar tulisan tidak terpotong printer */
            margin: 0 !important;
            height: 297mm !important; /* Tinggi kertas A4 */
            box-sizing: border-box !important;
            page-break-after: always;
            break-after: page;
            background-color: white !important;
          }
          .print-page:last-child {
            page-break-after: avoid;
            break-after: avoid;
          }
        }
      `}</style>
    </div>
  );
}
