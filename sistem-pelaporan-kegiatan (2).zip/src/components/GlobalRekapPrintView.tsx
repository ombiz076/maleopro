import React from "react";
import { Kegiatan } from "../types";
import { formatLabelDate } from "../utils";
import { Printer, X } from "lucide-react";

interface GlobalRekapPrintViewProps {
  currentList: Kegiatan[];
  onClose: () => void;
}

export default function GlobalRekapPrintView({ currentList, onClose }: GlobalRekapPrintViewProps) {
  const [showEditor, setShowEditor] = React.useState(false);
  const [settings, setSettings] = React.useState({
    pemerintah: "PEMERINTAH KABUPATEN POHUWATO",
    instansi: "BADAN PERENCANAAN,PENELITIAN DAN PENGEMBANGAN DAERAH",
    alamat: "Jalan M.H Thamrin, No.1, Blok Perkantoran Pemerintah Daerah",
    teleponEmail: "website : https://bapppeda.pohuwatokab.go.id/ | mail: bapppeda.pohuwato@gmail.com",
    logoType: 'uploaded' as 'none' | 'custom_text' | 'uploaded',
    logoText: "pohuwato",
    logoUrl: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj19y1_X-QqZ4yM0NzFEb-hm0K6fB1eR6TmlnyYdtRxgRhTpfTPcZbZXP8Sg78Mz3f-_3oktY2K7SR5wPimzSr2NnJxUT9F6CRZAZEwZYR7gF_nrueI4negUTlmLMFK4j7lsShsjVP0jPJGKQoFfCDNtS-D4Kb8rGMSJ67cZMd_Wry3H7ga7fHYTKISEffe/s1600/logo_app.png"
  });

  React.useEffect(() => {
    const saved = localStorage.getItem("kop_surat_settings");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.logoType === 'default') {
          parsed.logoType = 'none';
        }
        if (parsed.pemerintah === "PEMERINTAH KABUPATEN SENTOSA" || !parsed.pemerintah) {
          const freshDefaults = {
            pemerintah: "PEMERINTAH KABUPATEN POHUWATO",
            instansi: "BADAN PERENCANAAN,PENELITIAN DAN PENGEMBANGAN DAERAH",
            alamat: "Jalan M.H Thamrin, No.1, Blok Perkantoran Pemerintah Daerah",
            teleponEmail: "website : https://bapppeda.pohuwatokab.go.id/ | mail: bapppeda.pohuwato@gmail.com",
            logoType: 'uploaded' as 'none' | 'custom_text' | 'uploaded',
            logoText: "pohuwato",
            logoUrl: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj19y1_X-QqZ4yM0NzFEb-hm0K6fB1eR6TmlnyYdtRxgRhTpfTPcZbZXP8Sg78Mz3f-_3oktY2K7SR5wPimzSr2NnJxUT9F6CRZAZEwZYR7gF_nrueI4negUTlmLMFK4j7lsShsjVP0jPJGKQoFfCDNtS-D4Kb8rGMSJ67cZMd_Wry3H7ga7fHYTKISEffe/s1600/logo_app.png"
          };
          setSettings(freshDefaults);
          localStorage.setItem("kop_surat_settings", JSON.stringify(freshDefaults));
        } else {
          setSettings(parsed);
        }
      } catch (err) {
        console.error(err);
      }
    }
  }, []);

  const saveSettings = (newSettings: typeof settings) => {
    setSettings(newSettings);
    localStorage.setItem("kop_surat_settings", JSON.stringify(newSettings));
    window.dispatchEvent(new Event("kop_surat_changed"));
  };

  React.useEffect(() => {
    const handleSync = () => {
      const saved = localStorage.getItem("kop_surat_settings");
      if (saved) {
        try {
          setSettings(JSON.parse(saved));
        } catch (e) {}
      }
    };
    window.addEventListener("kop_surat_changed", handleSync);
    return () => window.removeEventListener("kop_surat_changed", handleSync);
  }, []);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        saveSettings({
          ...settings,
          logoType: 'uploaded',
          logoUrl: reader.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handlePrint = () => {
    window.print();
  };

  const today = new Date().toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 p-6 overflow-y-auto flex flex-col items-center justify-start backdrop-blur-xs print:bg-white print:p-0 print:overflow-visible print:static" id="rekap-print-modal">
      
      {/* CONFIGURATION PANEL (KOP SURAT MANAGER) - LANDSCAPE ALIGNED */}
      <div className="w-full max-w-[297mm] bg-slate-800 text-white rounded-xl shadow-xl p-5 mb-4 print:hidden border border-slate-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-xl">🏢</span>
            <div>
              <h3 className="font-bold text-sm text-slate-100">⚙️ Pengaturan Kop Surat Rekapitulasi</h3>
              <p className="text-[11px] text-slate-400">Sesuaikan logo, instansi, alamat dan info kontak secara global</p>
              <div className="mt-1.5 text-[10px] text-teal-400 font-medium bg-teal-950/40 px-2 py-0.5 rounded border border-teal-900/40 inline-block font-sans">
                💡 Sistem telah diset otomatis menyembunyikan header/footer browser. Jika browser Anda masih memunculkannya, hilangkan centang "Headers and footers" pada opsi cetak browser.
              </div>
            </div>
          </div>
          <button
            onClick={() => setShowEditor(!showEditor)}
            className="text-xs px-3 py-1.5 bg-slate-700 hover:bg-slate-600 rounded text-slate-200 transition-colors font-medium border border-slate-600"
          >
            {showEditor ? "Sembunyikan Pengaturan" : "Ubah Kop Surat Rekap"}
          </button>
        </div>

        {showEditor && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-3 border-t border-slate-700 text-xs text-left">
            <div className="space-y-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Tingkatan Pemerintah (Kapital)</label>
                <input
                  type="text"
                  value={settings.pemerintah}
                  onChange={(e) => saveSettings({ ...settings, pemerintah: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-teal-500 uppercase"
                  placeholder="PEMERINTAH KABUPATEN SENTOSA"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Nama Dinas / Instansi (Kapital)</label>
                <input
                  type="text"
                  value={settings.instansi}
                  onChange={(e) => saveSettings({ ...settings, instansi: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-teal-500 uppercase font-bold"
                  placeholder="DINAS KEPEGAWAIAN, INFRASTRUKTUR DAN PEMBANGUNAN DAERAH"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Alamat Kantor Dinas / Baris 3</label>
                <textarea
                  rows={2}
                  value={settings.alamat}
                  onChange={(e) => saveSettings({ ...settings, alamat: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-teal-500"
                  placeholder="Jalan Praja Utama No. 45, Kompleks..."
                />
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Kontak Dinas / Baris 4</label>
                <input
                  type="text"
                  value={settings.teleponEmail}
                  onChange={(e) => saveSettings({ ...settings, teleponEmail: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-teal-500"
                  placeholder="Telepon: (021)... | Email: ..."
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Format Logo</label>
                <div className="flex gap-2 mb-2">
                  <button
                    type="button"
                    onClick={() => saveSettings({ ...settings, logoType: 'none' })}
                    className={`flex-1 py-1 px-1.5 rounded text-[10px] font-semibold text-center border transition-all ${
                      settings.logoType === 'none'
                        ? 'bg-teal-700 text-white border-teal-600 shadow-inner'
                        : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    Tanpa Logo
                  </button>
                  <button
                    type="button"
                    onClick={() => saveSettings({ ...settings, logoType: 'custom_text' })}
                    className={`flex-1 py-1 px-1.5 rounded text-[10px] font-semibold text-center border transition-all ${
                      settings.logoType === 'custom_text'
                        ? 'bg-teal-700 text-white border-teal-600 shadow-inner'
                        : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    Teks Pendek
                  </button>
                  <button
                    type="button"
                    onClick={() => saveSettings({ ...settings, logoType: 'uploaded' })}
                    className={`flex-1 py-1 px-1.5 rounded text-[10px] font-semibold text-center border transition-all ${
                      settings.logoType === 'uploaded'
                        ? 'bg-teal-700 text-white border-teal-600 shadow-inner'
                        : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    Upload Gambar
                  </button>
                </div>

                {settings.logoType === 'custom_text' && (
                  <input
                    type="text"
                    maxLength={8}
                    value={settings.logoText}
                    onChange={(e) => saveSettings({ ...settings, logoText: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded text-slate-100 focus:outline-none focus:border-teal-500 uppercase text-center font-bold font-mono tracking-widest text-[13px]"
                    placeholder="Contoh: PUPR"
                  />
                )}

                {settings.logoType === 'uploaded' && (
                  <div className="flex gap-2 items-center">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="w-full text-slate-300 file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:text-[10px] file:font-semibold file:bg-slate-700 file:text-slate-100 hover:file:bg-slate-600"
                    />
                    {settings.logoUrl && (
                      <div className="w-10 h-10 border border-slate-600 bg-white rounded flex items-center justify-center overflow-hidden shrink-0">
                        <img src={settings.logoUrl} alt="Preview" className="max-w-full max-h-full object-contain" />
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="button"
                  onClick={() => {
                    const defaults = {
                      pemerintah: "PEMERINTAH KABUPATEN POHUWATO",
                      instansi: "BADAN PERENCANAAN,PENELITIAN DAN PENGEMBANGAN DAERAH",
                      alamat: "Jalan M.H Thamrin, No.1, Blok Perkantoran Pemerintah Daerah",
                      teleponEmail: "website : https://bapppeda.pohuwatokab.go.id/ | mail: bapppeda.pohuwato@gmail.com",
                      logoType: 'uploaded' as 'none' | 'custom_text' | 'uploaded',
                      logoText: "pohuwato",
                      logoUrl: "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj19y1_X-QqZ4yM0NzFEb-hm0K6fB1eR6TmlnyYdtRxgRhTpfTPcZbZXP8Sg78Mz3f-_3oktY2K7SR5wPimzSr2NnJxUT9F6CRZAZEwZYR7gF_nrueI4negUTlmLMFK4j7lsShsjVP0jPJGKQoFfCDNtS-D4Kb8rGMSJ67cZMd_Wry3H7ga7fHYTKISEffe/s1600/logo_app.png"
                    };
                    saveSettings(defaults);
                  }}
                  className="px-2.5 py-1 text-[10px] text-red-400 hover:text-red-300 bg-red-950/40 hover:bg-red-950/60 font-semibold border border-red-900/60 rounded transition-colors"
                >
                  Kembalikan ke Default
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* simulated landscape A4 width is ~297mm */}
      <div className="relative w-full max-w-[297mm] bg-white rounded-xl shadow-2xl p-8 border border-slate-200 print:static print:border-none print:shadow-none print:p-0 print:m-0 print:max-w-none" id="rekap-sheet">
        
        {/* Floating Print Controls for Rekap */}
        <div className="absolute top-4 right-4 flex items-center gap-2 print:hidden" id="rekap-controls">
          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold rounded shadow transition-transform hover:scale-105"
            title="Sembunyikan panel lalu panggil dialog pembuat PDF"
          >
            <Printer className="w-4 h-4" />
            Cetak Rekap A4 (Landscape)
          </button>
          
          <button
            onClick={onClose}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-900 rounded-full transition-colors"
            title="Tutup lembaran rekap"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Sheet Area */}
        <div className="print-rekap-page">
          
          {/* Header Kop - Aligned layout with logo just like single print view */}
          <div className="flex items-center gap-6 border-b-4 border-slate-900 pb-4 mb-6" id="kop-surat-rekap">
            {/* Logo placeholder */}
            {settings.logoType !== 'none' && (
              <div className="w-[70px] h-[70px] shrink-0 flex items-center justify-center">
                {settings.logoType === 'uploaded' && settings.logoUrl ? (
                  <img src={settings.logoUrl} alt="Logo Dinas" className="max-w-full max-h-full object-contain" />
                ) : settings.logoType === 'custom_text' ? (
                  <div className="w-[70px] h-[70px] bg-teal-800 text-white font-extrabold rounded-lg flex items-center justify-center border-2 border-teal-950 text-xs p-1 leading-tight text-center uppercase shadow-sm">
                    {settings.logoText || "LOGO"}
                  </div>
                ) : null}
              </div>
            )}
            
            <div className={`flex-1 text-center font-serif text-slate-900 ${settings.logoType !== 'none' ? 'pr-12' : ''}`}>
              <h1 className="text-base font-extrabold tracking-widest uppercase">{settings.pemerintah}</h1>
              <h2 className="text-sm font-bold tracking-wider uppercase text-slate-800">
                {settings.instansi}
              </h2>
              <p className="text-[10px] italic text-slate-500 font-sans tracking-tight">
                {settings.alamat} | {settings.teleponEmail}
              </p>
            </div>
          </div>

          {/* Title Document */}
          <div className="text-center mb-6 space-y-1">
            <h3 className="text-sm font-extrabold tracking-wider uppercase text-slate-900 underline">
              REKAPITULASI LAPORAN KEGIATAN PERJALANAN KEDINASAN
            </h3>
            <p className="text-[11px] font-medium text-slate-600 font-mono">
              Status Data: {currentList.length} Kegiatan Tercatat
            </p>
          </div>

          {/* Core spreadsheet A4 table */}
          <table className="w-full text-left text-[11px] border-collapse border border-slate-800" id="table-rekap-pdf">
            <thead>
              <tr className="bg-teal-50 border-b border-slate-800 text-slate-950 font-bold uppercase">
                <th className="border border-slate-800 px-2 py-2.5 text-center w-8">No</th>
                <th className="border border-slate-800 px-3 py-2.5 w-[250px]">Uraian / Judul Agenda</th>
                <th className="border border-slate-800 px-3 py-2.5 w-[220px]">Pelaksana Tugas</th>
                <th className="border border-slate-800 px-2.5 py-2.5 text-center w-[90px]">Tgl Lapor</th>
                <th className="border border-slate-800 px-3 py-2.5">Durasi & Waktu</th>
                <th className="border border-slate-800 px-2.5 py-2.5 text-center w-[80px]">Status</th>
              </tr>
            </thead>
            <tbody>
              {currentList.length > 0 ? (
                currentList.map((item, idx) => (
                  <tr key={item.id} className="border-b border-slate-800 text-slate-850 hover:bg-slate-50 select-text">
                    <td className="border border-slate-800 px-2 py-2 text-center font-mono font-bold">{idx + 1}</td>
                    <td className="border border-slate-800 px-3 py-2 font-medium break-words leading-relaxed">{item.judulKegiatan}</td>
                    <td className="border border-slate-800 px-3 py-2 leading-relaxed">
                      <div className="font-semibold text-slate-900">{item.namaPelaksana}</div>
                      <div className="text-[10px] text-slate-500 font-mono font-medium">{item.jabatan}</div>
                    </td>
                    <td className="border border-slate-800 px-2.5 py-2 text-center font-mono whitespace-nowrap">{item.tanggalLapor}</td>
                    <td className="border border-slate-800 px-3 py-2 leading-relaxed text-slate-700">
                      <div>Tgl: {formatLabelDate(item.startDate)} - {formatLabelDate(item.endDate)}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{item.startTime} - {item.endTime} WIB</div>
                    </td>
                    <td className="border border-slate-800 px-2.5 py-2 text-center font-bold">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${
                        item.status === "Terlapor"
                          ? "bg-green-100 text-green-700 font-bold"
                          : "bg-amber-100 text-amber-700 font-semibold"
                      }`}>
                        {item.status}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="border border-slate-800 px-4 py-8 text-center text-slate-400 italic">
                    Belum terdapat daftar laporan dinas yang lolos saringan kata kunci / tanggal.
                  </td>
                </tr>
              )}
            </tbody>
          </table>

          {/* Periodical bottom elements */}
          <div className="mt-8 flex flex-col gap-6 text-[11px] text-slate-800">
            <div>
              <p className="font-semibold">Catatan Pemeriksa:</p>
              <p className="text-[10px] text-slate-500 max-w-md italic mt-1 leading-relaxed">
                Tabel rekap ini otomatis menyesuaikan dengan pencarian dan filter kolaboratif yang dilakukan di dashboard website Sistem Informasi Pelaporan Kegiatan.
              </p>
            </div>
            
            {/* Added Footer bar as requested */}
            <div className="mt-6 pt-4 border-t border-dashed border-slate-300 text-center text-[10px] font-sans text-slate-500 italic select-none">
              * dicetak otomatis, melalui Sistem Pelaporan Kegiatan Internal Bapppeda Pohuwato *
            </div>
          </div>

        </div>

      </div>

      <style>{`
        @media print {
          @page {
            size: A4 landscape;
            margin: 0mm; /* Sembunyikan default header (Nama Sistem/Judul & Tanggal) & footer (Halaman & URL) bawaan browser */
          }
          body {
            visibility: hidden;
            background: white !important;
            margin: 0px !important;
          }
          #rekap-print-modal, #rekap-print-modal * {
            visibility: visible;
          }
          #rekap-sheet, #rekap-sheet * {
            visibility: visible;
          }
          #rekap-controls {
            display: none !important;
          }
          #rekap-print-modal {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            background: white !important;
            padding: 0 !important;
            margin: 0 !important;
            box-shadow: none !important;
            backdrop-filter: none !important;
            overflow: visible !important;
          }
          #rekap-sheet {
            border: none !important;
            box-shadow: none !important;
            padding: 0 !important;
            margin: 0 !important;
            width: 100% !important;
            max-width: none !important;
          }
          .print-rekap-page {
            padding: 15mm !important; /* Cadangkan margin cetak resmi landscape */
            box-sizing: border-box !important;
            background-color: white !important;
          }
        }
      `}</style>

    </div>
  );
}
