export interface Kegiatan {
  id: string;
  namaPelaksana: string;
  jabatan: string;
  nip: string;
  judulKegiatan: string;
  startDate: string;
  endDate: string;
  startTime: string;
  endTime: string;
  lokasi: string;
  tanggalLapor: string; //locked Indonesian date format
  regulasi: string[];
  resumeOriginal: string;
  resumeGenerated: string;
  images: string[]; // array of compressed base64 images
  status: "Draft" | "Terlapor";
  editCount?: number; // count of edits
  isOfflinePending?: boolean; // temporary flag for offline creation syncing
}

export interface SummaryRequest {
  resumeOriginal: string;
  judulKegiatan: string;
}

export interface SummaryResponse {
  summary: string;
}

export interface UserSession {
  name: string;
  email: string;
  avatarUrl?: string;
  jabatan?: string;
  nip?: string;
}
