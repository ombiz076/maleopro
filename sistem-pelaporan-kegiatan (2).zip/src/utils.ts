import { Kegiatan } from "./types";

// Indonesian month names for the locked date formatting
export const INDONESIAN_MONTHS = [
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember",
];

export function getLockedIndonesianDate(inputDate?: string | Date): string {
  const date = inputDate ? new Date(inputDate) : new Date();
  
  // Guard against invalid date
  if (isNaN(date.getTime())) {
    const todayFallback = new Date();
    const day = todayFallback.getDate();
    const monthIndex = todayFallback.getMonth();
    const year = todayFallback.getFullYear();
    return `${day} ${INDONESIAN_MONTHS[monthIndex]} ${year}`;
  }

  const day = date.getDate();
  const monthIndex = date.getMonth();
  const year = date.getFullYear();

  return `${day} ${INDONESIAN_MONTHS[monthIndex]} ${year}`;
}

export function formatLabelDate(dateStr: string): string {
  if (!dateStr) return "-";
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return dateStr;
  
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
}

/**
 * Compresses an image file on the client using HTML5 Canvas.
 * Caps maximum dimension at 800px and saves as image/jpeg with 0.7 quality.
 * This satisfies the user request to save compressed images in database.
 */
export function compressImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(event.target?.result as string); // fallback to original base64 if canvas context fails
          return;
        }

        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(img, 0, 0, width, height);
        
        // Export compressed as JPEG with 0.7 quality
        const compressedBase64 = canvas.toDataURL("image/jpeg", 0.7);
        resolve(compressedBase64);
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
}

/**
 * Parses a YYYY-MM-DD date string into a local Date object.
 * This bypasses UTC shifting discrepancies on different browsers.
 */
export function parseLocalDate(dateStr: string): Date {
  const parts = dateStr.split("-");
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);
  return new Date(year, month, day, 0, 0, 0, 0);
}

/**
 * Filters a list of Kegiatan by search text and calendar date calculations.
 * Supports: 'Semua', 'Hari Ini', 'Kemarin', 'Pekan Ini' (Rolling week - last 7 days)
 */
export function filterKegiatan(
  list: Kegiatan[],
  searchQuery: string,
  dateFilter: "all" | "today" | "yesterday" | "this_week"
): Kegiatan[] {
  // Safe internal dynamic date definitions based on client's local present date
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
  
  const yearStr = today.getFullYear();
  const monthStr = String(today.getMonth() + 1).padStart(2, '0');
  const dayStr = String(today.getDate()).padStart(2, '0');
  const TODAY_STR = `${yearStr}-${monthStr}-${dayStr}`;
  
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const YESTERDAY_STR = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;

  // Rolling week start (7 days ago)
  const rollingStart = new Date(today);
  rollingStart.setDate(today.getDate() - 6); // Includes today + 6 previous days = 7 days total
  rollingStart.setHours(0, 0, 0, 0);

  return list.filter((item) => {
    // 1. Keyword search check (Search in Title, Executor Name, JobTitle, Location, Or original/generated descriptions)
    const matchSearch =
      searchQuery.trim() === "" ||
      item.judulKegiatan.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.namaPelaksana.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.jabatan.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.lokasi.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.resumeOriginal.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.resumeGenerated.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchSearch) return false;

    // 2. Date ranges check (using item.startDate which represents duration range start)
    if (dateFilter === "all") return true;

    const itemDateStr = item.startDate; // "YYYY-MM-DD"
    if (dateFilter === "today") {
      return itemDateStr === TODAY_STR;
    }
    if (dateFilter === "yesterday") {
      return itemDateStr === YESTERDAY_STR;
    }
    if (dateFilter === "this_week") {
      const itemDate = parseLocalDate(itemDateStr);
      const limitEnd = new Date(today);
      limitEnd.setHours(23, 59, 59, 999);
      return itemDate >= rollingStart && itemDate <= limitEnd;
    }

    return true;
  });
}
